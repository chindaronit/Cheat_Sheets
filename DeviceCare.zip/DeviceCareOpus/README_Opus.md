# Device Care — Tizen TV Web Application

A production-grade Samsung Tizen TV web application that provides device health monitoring, storage management, and self-diagnosis capabilities. Built with vanilla JavaScript following a modular MVVM-inspired architecture with DPAD-first 10-foot UI design.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Architecture Diagram](#architecture-diagram)
3. [Class Diagram](#class-diagram)
4. [Sequence Diagrams](#sequence-diagrams)
5. [Project Structure](#project-structure)
6. [Functional Requirements](#functional-requirements)
7. [Non-Functional Requirements](#non-functional-requirements)
8. [Setup & Build Instructions](#setup--build-instructions)
9. [Emulator Setup](#emulator-setup)
10. [Navigation & Focus System](#navigation--focus-system)

---

## Architecture Overview

The application follows a layered modular architecture:

| Layer | Responsibility |
|---|---|
| **UI (Pages/Components)** | Renders HTML, binds to focus groups |
| **Navigation Graph** | Page lifecycle, back-stack, transitions |
| **Focus Manager** | DPAD spatial navigation, focus trapping |
| **DI Container** | Wires singletons and factories |
| **Repository** | Data access (simulated Tizen APIs) |
| **Event Bus** | Decoupled pub/sub communication |
| **Constants** | Key codes, routes, sizing tokens |

---

## Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│                        index.html                                │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │                     #app-root                              │  │
│  │  ┌─────────────┐ ┌─────────────────┐ ┌─────────────────┐  │  │
│  │  │  Home Page   │ │ Manage Storage  │ │ Self-Diagnosis  │  │  │
│  │  │             │ │     Page        │ │     Page        │  │  │
│  │  └──────┬──────┘ └───────┬─────────┘ └───────┬─────────┘  │  │
│  │         │                │                   │             │  │
│  │         └────────────────┼───────────────────┘             │  │
│  │                          │                                 │  │
│  │              ┌───────────▼───────────┐                     │  │
│  │              │   Navigation Graph    │                     │  │
│  │              │  (Route ↔ PageFactory)│                     │  │
│  │              └───────────┬───────────┘                     │  │
│  └──────────────────────────┼─────────────────────────────────┘  │
│                             │                                    │
│  ┌──────────────────────────▼──────────────────────────────────┐ │
│  │                    Core Services                             │ │
│  │  ┌──────────────┐ ┌──────────────┐ ┌─────────────────────┐  │ │
│  │  │ FocusManager │ │  Event Bus   │ │   DI Container      │  │ │
│  │  │ (DPAD nav)   │ │  (pub/sub)   │ │ (singleton/factory) │  │ │
│  │  └──────────────┘ └──────────────┘ └─────────┬───────────┘  │ │
│  └──────────────────────────────────────────────┼──────────────┘ │
│                                                 │                │
│  ┌──────────────────────────────────────────────▼──────────────┐ │
│  │                   Repository Layer                           │ │
│  │  ┌───────────────┐ ┌──────────────────┐ ┌───────────────┐   │ │
│  │  │ AppRepository │ │StorageRepository │ │DiagnosisRepo  │   │ │
│  │  └───────────────┘ └──────────────────┘ └───────────────┘   │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │                    CSS Framework                              │ │
│  │   reset │ theme │ layout │ components │ animations │ pages    │ │
│  └──────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

---

## Class Diagram

```
┌─────────────────────────┐
│       DIContainer       │
├─────────────────────────┤
│ - _singletons: Map      │
│ - _factories: Map       │
├─────────────────────────┤
│ + registerSingleton()   │
│ + registerFactory()     │
│ + resolve(name)         │
│ + static build()        │
└────────────┬────────────┘
             │ creates
             ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│    NavigationGraph      │────▶│       EventBus          │
├─────────────────────────┤     ├─────────────────────────┤
│ - _routes: Map          │     │ - _listeners: Map       │
│ - _backStack: string[]  │     ├─────────────────────────┤
│ - _currentPage: Page    │     │ + on(event, cb)         │
├─────────────────────────┤     │ + off(event, cb)        │
│ + register(name, fn)    │     │ + emit(event, data)     │
│ + init(root, start)     │     │ + once(event, cb)       │
│ + navigateTo(route)     │     │ + clear()               │
│ + goBack()              │     └─────────────────────────┘
└─────────────────────────┘
             │ mounts
             ▼
┌─────────────────────────┐
│     «interface» Page    │
├─────────────────────────┤
│ + render(): HTMLElement │
│ + onMount(): void       │
│ + onUnmount(): void     │
└────────────┬────────────┘
             │
    ┌────────┼────────────────────┐
    ▼        ▼                    ▼
┌──────────┐ ┌──────────────────┐ ┌────────────────────┐
│ HomePage │ │ManageStoragePage │ │SelfDiagnosisPage   │
├──────────┤ ├──────────────────┤ ├────────────────────┤
│storageRp │ │ appRepo          │ │ diagnosisRepo      │
└──────────┘ │ storageRepo      │ └────────────────────┘
             │ _dialog           │
             │ _cardInstances    │
             └──────────────────┘
                     │ uses
                     ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│    ViewDetailsDialog    │     │       AppCard           │
├─────────────────────────┤     ├─────────────────────────┤
│ - app: Object           │     │ - app: Object           │
│ - _isOpen: boolean      │     │ - selected: boolean     │
├─────────────────────────┤     ├─────────────────────────┤
│ + open(app, onAction)   │     │ + render()              │
│ + close()               │     │ + setSelected(bool)     │
│ + destroy()             │     │ + toggleSelected()      │
└─────────────────────────┘     └─────────────────────────┘

┌─────────────────────────┐     ┌─────────────────────────┐
│      FocusManager       │     │     «Repository»        │
├─────────────────────────┤     ├─────────────────────────┤
│ - _groups: Map          │     │  AppRepository          │
│ - _activeGroupId        │     │  StorageRepository      │
│ - _focusMemory: Map     │     │  DiagnosisRepository    │
│ - _dialogTrapping       │     └─────────────────────────┘
├─────────────────────────┤
│ + activate()            │     ┌─────────────────────────┐
│ + registerGroup()       │     │   «Component»           │
│ + focusGroup(id, idx)   │     ├─────────────────────────┤
│ + trapFocusInDialog()   │     │  HealthMeter            │
│ + releaseFocusTrap()    │     │  StorageBar             │
│ + saveFocusState()      │     │  DiagnosisCard          │
│ + restoreFocusState()   │     └─────────────────────────┘
└─────────────────────────┘
```

---

## Sequence Diagrams

### 1. App Bootstrap

```
User          Browser         app.js       DIContainer    NavGraph     FocusManager
 │               │               │              │             │             │
 │  open app     │               │              │             │             │
 │──────────────▶│  DOMReady     │              │             │             │
 │               │──────────────▶│  bootstrap() │             │             │
 │               │               │──────────────▶ build()     │             │
 │               │               │              │─┐ create    │             │
 │               │               │              │ │ repos     │             │
 │               │               │              │◀┘           │             │
 │               │               │◀─────────────│ container   │             │
 │               │               │─────────register routes───▶│             │
 │               │               │────────────────activate()──────────────▶│
 │               │               │─────────init(root,HOME)───▶│             │
 │               │               │              │  mountPage  │             │
 │               │               │              │   HomePage  │             │
 │               │               │              │     │       │registerGrps│
 │               │               │              │     │       │────────────▶│
 │               │◀──────────────│──────────────│─────│───────│─ rendered ─│
```

### 2. Navigate to Manage Storage

```
User        FocusManager    EventBus     NavGraph       ManageStoragePage
 │               │              │             │                │
 │  DPAD→Enter   │              │             │                │
 │──────────────▶│ focus:select │             │                │
 │               │─────────────▶│  navigate   │                │
 │               │              │────────────▶│                │
 │               │              │             │ unmount(Home)  │
 │               │              │             │ exit animation │
 │               │              │             │ mount(Storage) │
 │               │              │             │───────────────▶│ render()
 │               │              │             │                │ onMount()
 │               │  registerGroups            │                │
 │               │◀───────────────────────────│────────────────│
 │◀──────────────│──────────────│─────────────│── page shown ──│
```

### 3. Open View Details Dialog

```
User        FocusManager    EventBus     ManageStoragePage    ViewDetailsDialog   AppRepo
 │               │              │               │                    │              │
 │  Enter on     │              │               │                    │              │
 │  app card     │              │               │                    │              │
 │──────────────▶│ focus:select │               │                    │              │
 │               │─────────────▶│──────────────▶│ _openViewDetails() │              │
 │               │              │               │───getAppById()────────────────────▶│
 │               │              │               │◀──────app data ───────────────────│
 │               │              │               │───open(app, cb)───▶│              │
 │               │              │               │                    │ _render()    │
 │               │              │               │                    │ _setupFocus()│
 │               │ trapFocus    │               │                    │              │
 │               │◀─────────────│───────────────│────────────────────│              │
 │◀──────────────│──dialog shown│               │                    │              │
 │               │              │               │                    │              │
 │  Enter on     │              │               │                    │              │
 │  "Close"      │              │               │                    │              │
 │──────────────▶│ focus:select │               │                    │              │
 │               │─────────────▶│──────────────▶│◀── cb('close') ───│              │
 │               │              │               │───dialog.close()──▶│              │
 │               │ releaseTrap  │               │                    │              │
 │               │◀─────────────│───────────────│────────────────────│              │
 │◀──────────────│  focus restored              │                    │              │
```

### 4. BACK Key Navigation

```
User        FocusManager    EventBus     NavGraph        Current Page
 │               │              │             │                │
 │  BACK key     │              │             │                │
 │──────────────▶│ navigation:  │             │                │
 │               │ back         │             │                │
 │               │─────────────▶│────────────▶│ goBack()       │
 │               │              │             │───onUnmount()─▶│
 │               │              │             │  pop backStack │
 │               │              │             │  mount(prev)   │
 │               │  restoreFocusState()       │                │
 │               │◀───────────────────────────│                │
 │◀──────────────│  previous page shown       │                │
```

---

## Project Structure

```
DeviceCareOpus/
├── config.xml                    # Tizen widget configuration
├── .project                      # Tizen Studio project descriptor
├── index.html                    # Single HTML entry point
├── README.md                     # This documentation
│
├── css/
│   ├── reset.css                 # CSS reset for TV (1920×1080, no scroll)
│   ├── theme.css                 # Design tokens (colors, spacing, fonts)
│   ├── layout.css                # Page/grid/dialog layout primitives
│   ├── components.css            # Shared component styles (btn, card, focus)
│   ├── animations.css            # Keyframe animations & transitions
│   └── pages/
│       ├── home.css              # Home page styles
│       ├── manage-storage.css    # Manage Storage page styles
│       ├── self-diagnosis.css    # Self-Diagnosis page styles
│       └── view-details-dialog.css # View Details dialog styles
│
├── js/
│   ├── app.js                    # Bootstrap entry point
│   │
│   ├── core/
│   │   ├── navigation-graph.js   # Page router with back-stack
│   │   └── di-container.js       # Dependency injection container
│   │
│   ├── utils/
│   │   ├── constants.js          # Key codes, routes, config values
│   │   ├── event-bus.js          # Pub/sub event system
│   │   └── focus-manager.js      # DPAD 2D spatial focus navigation
│   │
│   ├── repository/
│   │   ├── app-repository.js     # Installed app data access
│   │   ├── storage-repository.js # Device storage data access
│   │   └── diagnosis-repository.js # Diagnosis test data access
│   │
│   ├── components/
│   │   ├── health-meter.js       # SVG semi-circular gauge
│   │   ├── app-card.js           # App card with checkbox
│   │   ├── storage-bar.js        # Horizontal storage progress bar
│   │   ├── diagnosis-card.js     # Colored diagnosis test card
│   │   └── view-details-dialog.js # Modal dialog for app details
│   │
│   └── pages/
│       ├── home-page.js          # Device Care home screen
│       ├── manage-storage-page.js # Storage management screen
│       └── self-diagnosis-page.js # Self-diagnosis screen
│
└── images/
    └── icon.svg                  # App icon (shield + checkmark)
```

---

## Functional Requirements

### FR-01: Home Screen (Device Care)
- **FR-01.1**: Display "Device Care" title (top-left, italic).
- **FR-01.2**: Render a semi-circular health meter showing device status (Good/Warning/Critical).
- **FR-01.3**: Display a shield icon with checkmark at the meter center.
- **FR-01.4**: Show status label ("Good") below the meter.
- **FR-01.5**: Provide a "Start Device Care" button (focusable).
- **FR-01.6**: Display bottom options row: Manage Storage, Self Diagnosis, Request Support.
- **FR-01.7**: Navigate to Manage Storage on Enter.
- **FR-01.8**: Navigate to Self-Diagnosis on Enter.
- **FR-01.9**: "Request Support" is non-functional (no-op).

### FR-02: Manage Storage Screen
- **FR-02.1**: Display "Manage Storage" title.
- **FR-02.2**: Show total/used storage as horizontal progress bar with labels.
- **FR-02.3**: Display selection count ("N item(s) selected").
- **FR-02.4**: Provide "Deselect All" and "Delete" action buttons.
- **FR-02.5**: Render installed apps as horizontal scrollable cards (LazyRow).
- **FR-02.6**: Each card shows: app icon placeholder, app name, total size.
- **FR-02.7**: Show checkbox on each card for multi-selection.
- **FR-02.8**: Show "View Details" link on focused card.
- **FR-02.9**: Open View Details dialog on Enter.
- **FR-02.10**: Deselect all apps when "Deselect All" is pressed.
- **FR-02.11**: Remove selected apps on "Delete" (simulated uninstall).

### FR-03: View Details Dialog
- **FR-03.1**: Display dialog overlay with "View Details" title.
- **FR-03.2**: Show app icon, name, and size breakdown (App/Data/Cache/Total).
- **FR-03.3**: Provide "Clear Data", "Clear Cache", "Close" buttons.
- **FR-03.4**: Clear app data on "Clear Data" and refresh display.
- **FR-03.5**: Clear app cache on "Clear Cache" and refresh display.
- **FR-03.6**: Close dialog on "Close" and restore focus.
- **FR-03.7**: Close dialog on BACK key press.

### FR-04: Self-Diagnosis Screen
- **FR-04.1**: Display "Self Diagnosis" title.
- **FR-04.2**: Show subtitle instruction text.
- **FR-04.3**: Render 7 colored test cards in 3-column grid:
  Video Test, Picture Test, Sound Test, HDMI Troubleshooting,
  Signal Information, Smart Hub Connection Test, Reset Smart Hub.
- **FR-04.4**: Scale-up animation on card focus.
- **FR-04.5**: Visual feedback on Enter (pulse animation).

### FR-05: Navigation
- **FR-05.1**: BACK key navigates to previous page.
- **FR-05.2**: BACK on Home exits the application (Tizen only).
- **FR-05.3**: Focus is saved and restored on back navigation.
- **FR-05.4**: Page transitions with slide/fade animations.

---

## Non-Functional Requirements

### NFR-01: TV Platform Compliance
- Fixed 1920x1080 resolution.
- 5% overscan-safe margins (96px horizontal, 54px vertical).
- No touch events — DPAD-only interaction.
- 10-foot UI typography (minimum 18px body text).
- No visible cursor.

### NFR-02: Focus Navigation
- Spatial 2D DPAD navigation (LEFT/RIGHT/UP/DOWN/ENTER/BACK).
- Focus groups with horizontal, vertical, and grid layouts.
- Focus memory per page — restored on back navigation.
- Dialog focus trapping (focus cannot leave dialog until closed).
- Focus glow/highlight animation on active element.
- Debounced key input (80ms) to prevent rapid-fire navigation.

### NFR-03: Performance
- No external dependencies (zero npm packages).
- All rendering via DOM manipulation (no virtual DOM overhead).
- LazyRow with CSS transform scrolling (GPU-accelerated).
- Animations via CSS keyframes (hardware-accelerated).
- < 500KB total application size.

### NFR-04: Accessibility
- ARIA labels on all interactive elements.
- Role attributes (button, dialog).
- High-contrast color scheme (WCAG AA on dark backgrounds).

### NFR-05: Architecture
- Modular file organization by concern.
- Dependency injection for testability.
- Pub/sub event bus for decoupled communication.
- Repository pattern for data abstraction.
- No global state leaks (all state in DC namespace).

---

## Setup & Build Instructions

### Prerequisites

1. **Tizen Studio 5.0+** with TV Extension installed
2. **Samsung TV Emulator** (TV 6.0 or later)
3. **Java JDK 8+** (required by Tizen Studio)

### Step 1: Install Tizen Studio

```bash
# Download from: https://developer.tizen.org/development/tizen-studio/download
# Run the installer and select:
#   - Tizen SDK Tools
#   - TV Extensions (6.0 or latest)
#   - TV Emulator
```

### Step 2: Import the Project

```
1. Open Tizen Studio
2. File → Import → Tizen → Tizen Project
3. Select the DeviceCareOpus directory
4. Project should appear in Project Explorer as "DeviceCare"
```

### Step 3: Build

```
1. Right-click project → Build Project
2. Verify no errors in the Problems tab
3. The .wgt package will be generated
```

### Step 4: Run on Emulator

```
1. Tools → Emulator Manager
2. Create a new TV emulator (1920x1080, TV 6.0)
3. Start the emulator
4. Right-click project → Run As → Tizen Web Application
5. Select the running emulator
```

### Step 5: Run on Physical TV (Optional)

```
1. Enable Developer Mode on your Samsung TV:
   Settings → General → System Manager → Developer Mode → ON
   Enter your PC's IP address
2. In Tizen Studio: Tools → Device Manager → Remote Device Manager
3. Add your TV's IP → Connect
4. Right-click project → Run As → Tizen Web Application
5. Select the connected TV
```

---

## Emulator Setup

### Create TV Emulator Profile

```
1. Open Tizen Studio → Tools → Emulator Manager
2. Click "Create" button
3. Select platform: tv-samsung-6.0-x86
4. Configure:
   - Name: TV_1920x1080
   - Resolution: 1920 x 1080
   - RAM: 2048 MB
   - CPU: 2 cores
5. Click "Finish"
6. Click "Launch" to start
```

### Keyboard Controls (Emulator)

| Remote Key | Keyboard Equivalent |
|---|---|
| DPAD Up | Arrow Up |
| DPAD Down | Arrow Down |
| DPAD Left | Arrow Left |
| DPAD Right | Arrow Right |
| Enter/OK | Enter |
| Back | Backspace or Escape |
| Red | F1 |
| Green | F2 |
| Yellow | F3 |
| Blue | F4 |

---

## Navigation & Focus System

### Focus Group Hierarchy

```
HOME PAGE
├── [home-start-btn]  ← "Start Device Care" (horizontal, 1 item)
└── [home-options]    ← Bottom options row (horizontal, 3 items)
    Vertical group order: start-btn → options

MANAGE STORAGE PAGE
├── [storage-actions] ← Deselect / Delete buttons (horizontal)
└── [storage-apps]    ← App cards LazyRow (horizontal, N items)
    Vertical group order: actions → apps

SELF-DIAGNOSIS PAGE
└── [diagnosis-cards] ← Test cards (grid, 3 columns)

VIEW DETAILS DIALOG (focus-trapped)
└── [dialog-buttons]  ← Clear Data / Clear Cache / Close (vertical)
```

### Focus Memory

Each page saves its focus state (active group + index within group) before unmounting. When navigating back, the saved state is restored so the user returns to exactly where they left off.

---

## License

This project is provided as-is for educational and development purposes.
