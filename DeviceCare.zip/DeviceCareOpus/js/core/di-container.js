/* ============================================================
   di-container.js — Simple Dependency Injection Container
   ============================================================
   Manages singleton services and provides factory functions
   that inject dependencies into pages and components.
   ============================================================ */

(function (DC) {
    'use strict';

    function DIContainer() {
        /** @type {Object.<string, Object>} Registered singletons */
        this._singletons = {};

        /** @type {Object.<string, Function>} Registered factories */
        this._factories = {};
    }

    /**
     * Register a singleton instance.
     * @param {string} name
     * @param {Object} instance
     */
    DIContainer.prototype.registerSingleton = function (name, instance) {
        this._singletons[name] = instance;
    };

    /**
     * Register a factory function.
     * @param {string} name
     * @param {Function} factory - (container) => instance
     */
    DIContainer.prototype.registerFactory = function (name, factory) {
        this._factories[name] = factory;
    };

    /**
     * Resolve a dependency by name.
     * Singletons are returned directly; factories create new instances.
     */
    DIContainer.prototype.resolve = function (name) {
        if (this._singletons[name]) {
            return this._singletons[name];
        }
        if (this._factories[name]) {
            return this._factories[name](this);
        }
        console.warn('[DI] Unknown dependency:', name);
        return null;
    };

    /**
     * Build the dependency graph for the Device Care app.
     * Called once at app startup.
     * @returns {DIContainer}
     */
    DIContainer.build = function () {
        var c = new DIContainer();

        // ---- Repositories (singletons) ----
        c.registerSingleton('appRepo',       new DC.AppRepository());
        c.registerSingleton('storageRepo',   new DC.StorageRepository());
        c.registerSingleton('diagnosisRepo', new DC.DiagnosisRepository());

        // ---- Navigation (singleton) ----
        c.registerSingleton('navGraph', new DC.NavigationGraph());

        // ---- Page Factories ----
        c.registerFactory('homePage', function (container) {
            return new DC.HomePage({
                storageRepo: container.resolve('storageRepo')
            });
        });

        c.registerFactory('manageStoragePage', function (container) {
            return new DC.ManageStoragePage({
                appRepo:     container.resolve('appRepo'),
                storageRepo: container.resolve('storageRepo')
            });
        });

        c.registerFactory('selfDiagnosisPage', function (container) {
            return new DC.SelfDiagnosisPage({
                diagnosisRepo: container.resolve('diagnosisRepo')
            });
        });

        return c;
    };

    DC.DIContainer = DIContainer;

})(window.DeviceCare = window.DeviceCare || {});
