/* ============================================================
   navigation-graph.js — Page Navigation Controller
   ============================================================
   Manages page lifecycle (mount/unmount), back-stack,
   animated transitions, and focus restoration.
   ============================================================ */

(function (DC) {
    'use strict';

    var Routes = DC.Constants.Routes;
    var TIMING = DC.Constants.Timing;

    /**
     * NavigationGraph — single-activity, multi-page navigation.
     */
    function NavigationGraph() {
        /** @type {Object.<string, Function>} Route → PageFactory */
        this._routes = {};

        /** @type {string[]} Back stack of route names */
        this._backStack = [];

        /** @type {string|null} Current active route */
        this._currentRoute = null;

        /** @type {Object|null} Current page instance */
        this._currentPage = null;

        /** @type {HTMLElement} The #app-root container */
        this._root = null;

        /** @type {boolean} Prevent double-navigation */
        this._transitioning = false;
    }

    /**
     * Register a route.
     * @param {string} name - Route name (from Constants.Routes)
     * @param {Function} factory - () => PageInstance  (must have render/onMount/onUnmount)
     */
    NavigationGraph.prototype.register = function (name, factory) {
        this._routes[name] = factory;
    };

    /**
     * Initialize with root element and start route.
     * @param {HTMLElement} root
     * @param {string} startRoute
     */
    NavigationGraph.prototype.init = function (root, startRoute) {
        this._root = root;
        this._bindNavEvents();
        this.navigateTo(startRoute);
    };

    /**
     * Navigate to a route (push).
     */
    NavigationGraph.prototype.navigateTo = function (route) {
        if (this._transitioning) return;
        if (!this._routes[route]) {
            console.warn('[NavGraph] Unknown route:', route);
            return;
        }

        this._transitioning = true;

        var self = this;

        // Save focus state for current page
        if (this._currentRoute) {
            DC.FocusManager.saveFocusState(this._currentRoute);
        }

        // Unmount current page with exit animation
        if (this._currentPage) {
            var oldPage = this._currentPage;
            var oldEl = oldPage.el;
            if (oldEl) {
                oldEl.classList.add('page-exit');
                oldEl.classList.remove('active');
            }
            oldPage.onUnmount();

            // Push to back stack
            this._backStack.push(this._currentRoute);

            setTimeout(function () {
                if (oldEl && oldEl.parentNode) {
                    oldEl.parentNode.removeChild(oldEl);
                }
                self._mountRoute(route);
            }, TIMING.PAGE_TRANSITION_MS);
        } else {
            this._mountRoute(route);
        }
    };

    /**
     * Go back to previous page.
     */
    NavigationGraph.prototype.goBack = function () {
        if (this._transitioning) return;

        if (this._backStack.length === 0) {
            // At root — exit app on Tizen
            try {
                if (window.tizen && window.tizen.application) {
                    tizen.application.getCurrentApplication().exit();
                }
            } catch (e) {
                // Not on Tizen device
            }
            return;
        }

        this._transitioning = true;
        var prevRoute = this._backStack.pop();
        var self = this;

        // Exit current page
        if (this._currentPage) {
            var oldPage = this._currentPage;
            var oldEl = oldPage.el;
            if (oldEl) {
                oldEl.classList.add('page-exit');
                oldEl.classList.remove('active');
            }
            oldPage.onUnmount();

            setTimeout(function () {
                if (oldEl && oldEl.parentNode) {
                    oldEl.parentNode.removeChild(oldEl);
                }
                self._mountRoute(prevRoute, true);
            }, TIMING.PAGE_TRANSITION_MS);
        } else {
            this._mountRoute(prevRoute, true);
        }
    };

    /**
     * Get current route name.
     */
    NavigationGraph.prototype.getCurrentRoute = function () {
        return this._currentRoute;
    };

    /* ---- Internal ---- */

    NavigationGraph.prototype._mountRoute = function (route, isBack) {
        var factory = this._routes[route];
        if (!factory) return;

        var page = factory();
        var el = page.render();
        el.classList.add('page-enter');

        this._root.appendChild(el);

        // Force reflow before adding active class
        void el.offsetHeight;
        el.classList.add('active');

        this._currentRoute = route;
        this._currentPage = page;

        page.onMount();

        // Try to restore focus state if navigating back
        if (isBack) {
            DC.FocusManager.restoreFocusState(route);
        }

        var self = this;
        setTimeout(function () {
            el.classList.remove('page-enter');
            self._transitioning = false;
        }, TIMING.PAGE_TRANSITION_MS);
    };

    NavigationGraph.prototype._bindNavEvents = function () {
        var self = this;

        // Navigation events from pages
        DC.EventBus.on('navigate', function (data) {
            if (data && data.route) {
                self.navigateTo(data.route);
            }
        });

        // Back button
        DC.EventBus.on('navigation:back', function () {
            // Check if a dialog is open first
            if (DC.FocusManager._dialogTrapping) {
                // Let the dialog handle its own close via the focus manager
                DC.EventBus.emit('dialog:backPressed');
                return;
            }
            self.goBack();
        });
    };

    DC.NavigationGraph = NavigationGraph;

})(window.DeviceCare = window.DeviceCare || {});
