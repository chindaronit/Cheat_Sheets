/* ============================================================
   app-card.js — App Card Component for Manage Storage
   ============================================================ */

(function (DC) {
    'use strict';

    /**
     * Creates an app card element for the storage grid.
     * @param {Object} app - App data object from AppRepository
     * @param {Object} [opts]
     * @param {boolean} [opts.selected] - Whether the card is selected
     * @returns {HTMLElement}
     */
    function AppCard(app, opts) {
        this.app = app;
        this.selected = (opts && opts.selected) || false;
        this.el = null;
    }

    AppCard.prototype.render = function () {
        var app = this.app;

        var card = document.createElement('div');
        card.className = 'app-card focusable';
        card.setAttribute('tabindex', '0');
        card.setAttribute('data-app-id', app.id);
        card.setAttribute('data-action', 'toggle-select');
        card.setAttribute('role', 'button');
        card.setAttribute('aria-label', app.name + ', ' + app.totalSize + ' ' + app.totalSizeUnit);

        // Checkbox indicator
        var checkbox = document.createElement('div');
        checkbox.className = 'checkbox-indicator' + (this.selected ? ' checked' : '');
        card.appendChild(checkbox);

        // Icon area
        var iconArea = document.createElement('div');
        iconArea.className = 'app-card__icon-area';
        iconArea.style.backgroundColor = app.color || '#37474F';

        var placeholder = document.createElement('div');
        placeholder.className = 'app-card__icon-placeholder';
        if (app.darkText) {
            placeholder.style.color = '#333';
        }
        placeholder.textContent = app.iconText || app.name.charAt(0).toUpperCase();
        iconArea.appendChild(placeholder);
        card.appendChild(iconArea);

        // Info section
        var info = document.createElement('div');
        info.className = 'app-card__info';

        var name = document.createElement('div');
        name.className = 'app-card__name';
        name.textContent = app.name;
        info.appendChild(name);

        var size = document.createElement('div');
        size.className = 'app-card__size';
        size.textContent = app.totalSize + ' ' + app.totalSizeUnit;
        info.appendChild(size);

        card.appendChild(info);

        this.el = card;
        return card;
    };

    AppCard.prototype.setSelected = function (isSelected) {
        this.selected = isSelected;
        if (this.el) {
            var checkbox = this.el.querySelector('.checkbox-indicator');
            if (checkbox) {
                if (isSelected) {
                    checkbox.classList.add('checked');
                } else {
                    checkbox.classList.remove('checked');
                }
            }
        }
    };

    AppCard.prototype.toggleSelected = function () {
        this.setSelected(!this.selected);
        return this.selected;
    };

    DC.AppCard = AppCard;

})(window.DeviceCare = window.DeviceCare || {});
