/* ============================================================
   health-meter.js — Semi-circular Health Meter Component
   ============================================================ */

(function (DC) {
    'use strict';

    /**
     * Renders a semi-circular SVG gauge with a shield icon.
     * @param {Object} opts
     * @param {string} opts.status - 'Good' | 'Warning' | 'Critical'
     * @param {number} opts.percentage - 0-100 fill amount
     * @returns {HTMLElement}
     */
    function HealthMeter(opts) {
        this.status = opts.status || DC.Constants.HealthStatus.GOOD;
        this.percentage = opts.percentage || 0;
        this.el = null;
    }

    HealthMeter.prototype.render = function () {
        var container = document.createElement('div');
        container.className = 'health-meter-container';

        // Determine color based on status
        var arcColor;
        switch (this.status) {
            case DC.Constants.HealthStatus.GOOD:
                arcColor = '#4dd9e8';
                break;
            case DC.Constants.HealthStatus.WARNING:
                arcColor = '#f39c12';
                break;
            case DC.Constants.HealthStatus.CRITICAL:
                arcColor = '#e74c3c';
                break;
            default:
                arcColor = '#4dd9e8';
        }

        // SVG semi-circular arc
        // Arc center at (140, 140), radius 120, from 180deg to 0deg (semi-circle)
        var radius = 120;
        var circumference = Math.PI * radius; // half-circle circumference
        var fillLength = (this.percentage / 100) * circumference;
        var dashOffset = circumference - fillLength;

        var svg = '<svg viewBox="0 0 280 160" xmlns="http://www.w3.org/2000/svg">' +
            // Background arc (track)
            '<path d="M 20 150 A 120 120 0 0 1 260 150" ' +
                'fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="8" stroke-linecap="round"/>' +
            // Foreground arc (fill)
            '<path class="health-meter-arc" ' +
                'd="M 20 150 A 120 120 0 0 1 260 150" ' +
                'fill="none" stroke="' + arcColor + '" stroke-width="8" stroke-linecap="round" ' +
                'stroke-dasharray="' + circumference + '" ' +
                'stroke-dashoffset="' + dashOffset + '"/>' +
            '</svg>';

        container.innerHTML = svg;

        // Shield icon in center bottom
        var iconDiv = document.createElement('div');
        iconDiv.className = 'health-meter-icon';
        iconDiv.innerHTML = '<svg viewBox="0 0 24 24" fill="' + arcColor + '" xmlns="http://www.w3.org/2000/svg">' +
            '<path d="M12 2L3 7v5c0 5.25 3.83 10.15 9 11.25C17.17 22.15 21 17.25 21 12V7l-9-5z"/>' +
            '<path d="M10 15.5l-3-3 1.41-1.41L10 12.67l5.59-5.59L17 8.5l-7 7z" fill="white"/>' +
            '</svg>';
        container.appendChild(iconDiv);

        this.el = container;
        return container;
    };

    HealthMeter.prototype.update = function (status, percentage) {
        this.status = status;
        this.percentage = percentage;
        if (this.el && this.el.parentNode) {
            var parent = this.el.parentNode;
            var newEl = this.render();
            parent.replaceChild(newEl, this.el);
        }
    };

    DC.HealthMeter = HealthMeter;

})(window.DeviceCare = window.DeviceCare || {});
