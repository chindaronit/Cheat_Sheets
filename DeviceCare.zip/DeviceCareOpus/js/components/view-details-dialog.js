/* ============================================================
   view-details-dialog.js — View Details Dialog Component
   ============================================================ */

(function (DC) {
    'use strict';

    var FG = DC.Constants.FocusGroup;

    /**
     * View Details Dialog — shows app info with Clear Data / Clear Cache / Close buttons.
     */
    function ViewDetailsDialog() {
        this.el = null;
        this.app = null;
        this._isOpen = false;
        this._onAction = null;  // callback(action, appId)
    }

    /**
     * Open the dialog for a given app.
     * @param {Object} app - App data from AppRepository
     * @param {Function} onAction - callback('clearData'|'clearCache'|'close', appId)
     */
    ViewDetailsDialog.prototype.open = function (app, onAction) {
        this.app = app;
        this._onAction = onAction;
        this._isOpen = true;
        this._render();
        this._setupFocus();
    };

    /** Close and destroy the dialog */
    ViewDetailsDialog.prototype.close = function () {
        this._isOpen = false;
        DC.FocusManager.unregisterGroup(FG.DIALOG_BUTTONS);
        DC.FocusManager.releaseFocusTrap();

        if (this.el) {
            this.el.classList.remove('visible');
            this.el.classList.add('overlay-exit');
            var self = this;
            setTimeout(function () {
                if (self.el && self.el.parentNode) {
                    self.el.parentNode.removeChild(self.el);
                }
                self.el = null;
            }, DC.Constants.Timing.DIALOG_ANIM_MS);
        }
    };

    ViewDetailsDialog.prototype.isOpen = function () {
        return this._isOpen;
    };

    /* ---- Internal: Render ---- */
    ViewDetailsDialog.prototype._render = function () {
        // Remove previous dialog if exists
        if (this.el && this.el.parentNode) {
            this.el.parentNode.removeChild(this.el);
        }

        var app = this.app;

        // Overlay
        var overlay = document.createElement('div');
        overlay.className = 'dialog-overlay view-details-dialog overlay-enter';

        // Dialog box
        var box = document.createElement('div');
        box.className = 'dialog-box dialog-enter';

        // Header
        var header = document.createElement('div');
        header.className = 'view-details-dialog__header';
        var title = document.createElement('h2');
        title.className = 'view-details-dialog__title';
        title.textContent = 'View Details';
        header.appendChild(title);
        box.appendChild(header);

        // Body
        var body = document.createElement('div');
        body.className = 'view-details-dialog__body';

        // App identity (icon + name)
        var identity = document.createElement('div');
        identity.className = 'view-details-dialog__app-identity';

        var iconBox = document.createElement('div');
        iconBox.className = 'view-details-dialog__app-icon';
        iconBox.style.backgroundColor = app.color || '#37474F';

        var iconPlaceholder = document.createElement('span');
        iconPlaceholder.className = 'view-details-dialog__app-icon-placeholder';
        if (app.darkText) iconPlaceholder.style.color = '#333';
        iconPlaceholder.textContent = app.iconText || app.name.charAt(0);
        iconBox.appendChild(iconPlaceholder);
        identity.appendChild(iconBox);

        var appName = document.createElement('div');
        appName.className = 'view-details-dialog__app-name';
        appName.textContent = app.name;
        identity.appendChild(appName);

        // Action row: identity + info + buttons
        var actionRow = document.createElement('div');
        actionRow.className = 'view-details-dialog__action-row';
        actionRow.appendChild(identity);

        // Info rows
        var infoSection = document.createElement('div');
        infoSection.className = 'view-details-dialog__content-area';

        var rows = [
            { label: 'App',   value: app.appSize + ' ' + app.appSizeUnit },
            { label: 'Data',  value: app.dataSize + ' ' + app.dataSizeUnit },
            { label: 'Cache', value: app.cacheSize + ' ' + app.cacheSizeUnit },
            { label: 'Total', value: app.totalSize + ' ' + app.totalSizeUnit }
        ];

        rows.forEach(function (r) {
            var row = document.createElement('div');
            row.className = 'info-row';

            var lbl = document.createElement('span');
            lbl.className = 'info-row__label';
            lbl.textContent = r.label;
            row.appendChild(lbl);

            var val = document.createElement('span');
            val.className = 'info-row__value';
            val.textContent = r.value;
            row.appendChild(val);

            infoSection.appendChild(row);
        });

        actionRow.appendChild(infoSection);

        // Buttons column
        var buttonsArea = document.createElement('div');
        buttonsArea.className = 'view-details-dialog__buttons-area';

        var btnClearData = this._createButton('Clear Data', 'btn-secondary', 'clearData');
        var btnClearCache = this._createButton('Clear Cache', 'btn-secondary', 'clearCache');
        var btnClose = this._createButton('Close', 'btn-primary', 'close');

        buttonsArea.appendChild(btnClearData);
        buttonsArea.appendChild(btnClearCache);
        buttonsArea.appendChild(btnClose);

        actionRow.appendChild(buttonsArea);
        body.appendChild(actionRow);
        box.appendChild(body);
        overlay.appendChild(box);

        document.getElementById('app-root').appendChild(overlay);

        // Make visible after paint
        requestAnimationFrame(function () {
            overlay.classList.add('visible');
        });

        this.el = overlay;
    };

    ViewDetailsDialog.prototype._createButton = function (text, styleClass, action) {
        var btn = document.createElement('button');
        btn.className = 'btn ' + styleClass + ' focusable';
        btn.setAttribute('tabindex', '0');
        btn.setAttribute('data-action', action);
        btn.textContent = text;
        return btn;
    };

    /* ---- Internal: Focus Setup ---- */
    ViewDetailsDialog.prototype._setupFocus = function () {
        var buttons = this.el.querySelectorAll('.view-details-dialog__buttons-area .btn');
        var items = Array.prototype.slice.call(buttons);

        DC.FocusManager.registerGroup(FG.DIALOG_BUTTONS, items, 'vertical');
        DC.FocusManager.trapFocusInDialog(FG.DIALOG_BUTTONS);

        // Listen for selection
        var self = this;
        this._selectHandler = function (data) {
            if (data.groupId !== FG.DIALOG_BUTTONS) return;
            var action = data.element.getAttribute('data-action');
            if (action && self._onAction) {
                self._onAction(action, self.app.id);
            }
        };
        DC.EventBus.on('focus:select', this._selectHandler);
    };

    /** Clean up event listeners */
    ViewDetailsDialog.prototype.destroy = function () {
        if (this._selectHandler) {
            DC.EventBus.off('focus:select', this._selectHandler);
        }
        this.close();
    };

    DC.ViewDetailsDialog = ViewDetailsDialog;

})(window.DeviceCare = window.DeviceCare || {});
