/* ============================================================
   diagnosis-card.js — Diagnosis Test Card Component
   ============================================================ */

(function (DC) {
    'use strict';

    /**
     * @param {Object} test - { id, label, cssClass }
     */
    function DiagnosisCard(test) {
        this.test = test;
        this.el = null;
    }

    DiagnosisCard.prototype.render = function () {
        var card = document.createElement('div');
        card.className = 'diagnosis-card focusable ' + this.test.cssClass;
        card.setAttribute('tabindex', '0');
        card.setAttribute('data-test-id', this.test.id);
        card.setAttribute('role', 'button');
        card.setAttribute('aria-label', this.test.label);

        var label = document.createElement('span');
        label.className = 'diagnosis-card__label';
        label.textContent = this.test.label;
        card.appendChild(label);

        this.el = card;
        return card;
    };

    DC.DiagnosisCard = DiagnosisCard;

})(window.DeviceCare = window.DeviceCare || {});
