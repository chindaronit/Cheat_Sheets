/* ============================================================
   storage-bar.js — Storage Progress Bar Component
   ============================================================ */

(function (DC) {
    'use strict';

    /**
     * Horizontal storage progress bar with used/available labels.
     * @param {Object} opts
     * @param {number} opts.usedGB
     * @param {number} opts.totalGB
     */
    function StorageBar(opts) {
        this.usedGB = opts.usedGB || 0;
        this.totalGB = opts.totalGB || 1;
        this.el = null;
    }

    StorageBar.prototype.render = function () {
        var container = document.createElement('div');
        container.className = 'storage-info';

        var availableGB = parseFloat((this.totalGB - this.usedGB).toFixed(2));
        var pct = Math.round((this.usedGB / this.totalGB) * 100);

        // Labels row
        var labels = document.createElement('div');
        labels.className = 'storage-info__labels';

        var usedLabel = document.createElement('span');
        usedLabel.className = 'storage-info__label-used';
        usedLabel.textContent = 'Used ' + this.usedGB.toFixed(2) + ' GB';
        labels.appendChild(usedLabel);

        var availLabel = document.createElement('span');
        availLabel.className = 'storage-info__label-available';
        availLabel.textContent = 'Available ' + availableGB.toFixed(2) + ' GB(' + pct + '%)';
        labels.appendChild(availLabel);

        container.appendChild(labels);

        // Progress bar
        var bar = document.createElement('div');
        bar.className = 'storage-progress-bar';

        var fill = document.createElement('div');
        fill.className = 'storage-progress-bar__fill';
        fill.style.width = pct + '%';
        bar.appendChild(fill);

        container.appendChild(bar);

        this.el = container;
        return container;
    };

    StorageBar.prototype.update = function (usedGB, totalGB) {
        this.usedGB = usedGB;
        this.totalGB = totalGB;
        if (this.el && this.el.parentNode) {
            var parent = this.el.parentNode;
            var newEl = this.render();
            parent.replaceChild(newEl, this.el);
        }
    };

    DC.StorageBar = StorageBar;

})(window.DeviceCare = window.DeviceCare || {});
