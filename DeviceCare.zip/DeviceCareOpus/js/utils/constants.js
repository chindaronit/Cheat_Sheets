/* ============================================================
   constants.js — Application Constants & Key Codes
   ============================================================ */

var DeviceCare = window.DeviceCare || {};

DeviceCare.Constants = {

    /* ---- Tizen TV Remote Key Codes ---- */
    KeyCode: {
        LEFT:       37,
        UP:         38,
        RIGHT:      39,
        DOWN:       40,
        ENTER:      13,
        BACK:       10009,  // Tizen BACK key
        EXIT:       10182,  // Tizen EXIT key (close app)
        RED:        403,
        GREEN:      404,
        YELLOW:     405,
        BLUE:       406,
        CH_UP:      427,
        CH_DOWN:    428,
        VOL_UP:     447,
        VOL_DOWN:   448,
        MUTE:       449,
        INFO:       457,
        MENU:       18,
        PLAY:       415,
        PAUSE:      19,
        STOP:       413
    },

    /* ---- Page Route Names ---- */
    Routes: {
        HOME:            'home',
        MANAGE_STORAGE:  'manage-storage',
        SELF_DIAGNOSIS:  'self-diagnosis'
    },

    /* ---- Focus Group IDs ---- */
    FocusGroup: {
        HOME_OPTIONS:       'home-options',
        HOME_START_BTN:     'home-start-btn',
        STORAGE_ACTIONS:    'storage-actions',
        STORAGE_APPS:       'storage-apps',
        STORAGE_VIEW_DETAIL:'storage-view-detail',
        DIAGNOSIS_CARDS:    'diagnosis-cards',
        DIALOG_BUTTONS:     'dialog-buttons'
    },

    /* ---- Storage ---- */
    Storage: {
        TOTAL_GB: 3.82,   // Example total storage
        UNIT_KB: 'KB',
        UNIT_MB: 'MB',
        UNIT_GB: 'GB',
        UNIT_B:  'B'
    },

    /* ---- Health Status ---- */
    HealthStatus: {
        GOOD:     'Good',
        WARNING:  'Warning',
        CRITICAL: 'Critical'
    },

    /* ---- Diagnosis Test Types ---- */
    DiagnosisTests: [
        { id: 'video',      label: 'Video Test',                 cssClass: 'diagnosis-card--video' },
        { id: 'picture',    label: 'Picture Test',               cssClass: 'diagnosis-card--picture' },
        { id: 'sound',      label: 'Sound Test',                 cssClass: 'diagnosis-card--sound' },
        { id: 'hdmi',       label: 'HDMI Troubleshooting',       cssClass: 'diagnosis-card--hdmi' },
        { id: 'signal',     label: 'Signal Information',         cssClass: 'diagnosis-card--signal' },
        { id: 'smarthub',   label: 'Smart Hub Connection Test',  cssClass: 'diagnosis-card--smarthub' },
        { id: 'reset',      label: 'Reset Smart Hub',            cssClass: 'diagnosis-card--reset' }
    ],

    /* ---- Timing ---- */
    Timing: {
        PAGE_TRANSITION_MS: 300,
        DIALOG_ANIM_MS:     250,
        FOCUS_DEBOUNCE_MS:  80,
        SCROLL_SPEED_MS:    250
    }
};

window.DeviceCare = DeviceCare;
