/* ============================================================
   focus-manager.js — DPAD Focus Navigation Manager
   ============================================================
   Handles 2D spatial focus navigation for Tizen TV.
   Supports focus groups (rows/grids), focus memory per page,
   lazy-row scrolling, and dialog focus trapping.
   ============================================================ */

(function (DC) {
    'use strict';

    var KC = DC.Constants.KeyCode;
    var TIMING = DC.Constants.Timing;

    /* --------------------------------------------------------
       FocusManager Constructor
       -------------------------------------------------------- */
    function FocusManager() {
        /** @type {Object.<string, FocusGroup>} */
        this._groups = {};

        /** @type {string|null} Current active group ID */
        this._activeGroupId = null;

        /** @type {Object.<string, number>} Saved focus index per group */
        this._focusMemory = {};

        /** @type {string[]} Group navigation order (vertical) */
        this._groupOrder = [];

        /** @type {boolean} Whether a dialog is trapping focus */
        this._dialogTrapping = false;

        /** @type {string|null} Dialog focus group ID */
        this._dialogGroupId = null;

        /** @type {string|null} Group ID before dialog opened */
        this._preDialogGroupId = null;

        /** @type {number|null} Focus index before dialog opened */
        this._preDialogIndex = null;

        /** @type {number} debounce timer */
        this._debounceTimer = null;

        // Bind keydown handler
        this._onKeyDown = this._handleKeyDown.bind(this);
    }

    /* --------------------------------------------------------
       FocusGroup data structure
       -------------------------------------------------------- */
    /**
     * @typedef {Object} FocusGroup
     * @property {string} id
     * @property {HTMLElement[]} items - Focusable elements in order
     * @property {'horizontal'|'vertical'|'grid'} layout
     * @property {number} columns - Grid columns (only for grid layout)
     * @property {number} focusIndex - Current focused index
     * @property {Function|null} onScrollNeeded - Callback when scrolling is needed
     */

    /* --------------------------------------------------------
       Public API
       -------------------------------------------------------- */

    /** Start listening for key events */
    FocusManager.prototype.activate = function () {
        document.addEventListener('keydown', this._onKeyDown);
    };

    /** Stop listening */
    FocusManager.prototype.deactivate = function () {
        document.removeEventListener('keydown', this._onKeyDown);
    };

    /**
     * Register a focus group.
     * @param {string} id
     * @param {HTMLElement[]} items
     * @param {'horizontal'|'vertical'|'grid'} layout
     * @param {Object} [opts]
     * @param {number} [opts.columns] - Grid columns
     * @param {Function} [opts.onScrollNeeded] - (focusIndex, element) => void
     */
    FocusManager.prototype.registerGroup = function (id, items, layout, opts) {
        opts = opts || {};
        this._groups[id] = {
            id: id,
            items: items,
            layout: layout || 'horizontal',
            columns: opts.columns || 3,
            focusIndex: this._focusMemory[id] || 0,
            onScrollNeeded: opts.onScrollNeeded || null
        };
    };

    /** Unregister a group */
    FocusManager.prototype.unregisterGroup = function (id) {
        delete this._groups[id];
        var idx = this._groupOrder.indexOf(id);
        if (idx !== -1) this._groupOrder.splice(idx, 1);
        if (this._activeGroupId === id) {
            this._activeGroupId = this._groupOrder[0] || null;
        }
    };

    /** Clear all groups (e.g., on page change) */
    FocusManager.prototype.clearGroups = function () {
        // Save focus memory for all current groups
        for (var id in this._groups) {
            this._focusMemory[id] = this._groups[id].focusIndex;
        }
        this._groups = {};
        this._groupOrder = [];
        this._activeGroupId = null;
        this._dialogTrapping = false;
        this._dialogGroupId = null;
    };

    /**
     * Set the vertical order of groups for UP/DOWN navigation between groups.
     * @param {string[]} orderedIds
     */
    FocusManager.prototype.setGroupOrder = function (orderedIds) {
        this._groupOrder = orderedIds;
    };

    /**
     * Focus the first item (or saved index) in a group.
     * @param {string} groupId
     * @param {number} [index] - Optional specific index
     */
    FocusManager.prototype.focusGroup = function (groupId, index) {
        var group = this._groups[groupId];
        if (!group || group.items.length === 0) return;

        this._activeGroupId = groupId;
        var i = (typeof index === 'number') ? index : (this._focusMemory[groupId] || 0);
        i = Math.min(i, group.items.length - 1);
        i = Math.max(i, 0);
        this._setFocus(group, i);
    };

    /** Get currently focused element */
    FocusManager.prototype.getCurrentElement = function () {
        var group = this._groups[this._activeGroupId];
        if (!group) return null;
        return group.items[group.focusIndex] || null;
    };

    /** Get active group ID */
    FocusManager.prototype.getActiveGroupId = function () {
        return this._activeGroupId;
    };

    /* ---- Dialog Focus Trapping ---- */

    /**
     * Trap focus inside a dialog group.
     */
    FocusManager.prototype.trapFocusInDialog = function (dialogGroupId) {
        this._preDialogGroupId = this._activeGroupId;
        var currentGroup = this._groups[this._activeGroupId];
        this._preDialogIndex = currentGroup ? currentGroup.focusIndex : 0;

        this._dialogTrapping = true;
        this._dialogGroupId = dialogGroupId;
        this.focusGroup(dialogGroupId, 0);
    };

    /**
     * Release dialog focus trap, restoring previous focus.
     */
    FocusManager.prototype.releaseFocusTrap = function () {
        this._dialogTrapping = false;
        this._dialogGroupId = null;

        if (this._preDialogGroupId) {
            this.focusGroup(this._preDialogGroupId, this._preDialogIndex);
            this._preDialogGroupId = null;
            this._preDialogIndex = null;
        }
    };

    /**
     * Update items in an existing group (e.g., after DOM changes)
     */
    FocusManager.prototype.updateGroupItems = function (groupId, newItems) {
        var group = this._groups[groupId];
        if (!group) return;
        group.items = newItems;
        if (group.focusIndex >= newItems.length) {
            group.focusIndex = Math.max(0, newItems.length - 1);
        }
    };

    /**
     * Save current focus state for restoration.
     * @param {string} pageId
     */
    FocusManager.prototype.saveFocusState = function (pageId) {
        this._focusMemory['__page_' + pageId] = {
            groupId: this._activeGroupId,
            groups: {}
        };
        for (var id in this._groups) {
            this._focusMemory['__page_' + pageId].groups[id] = this._groups[id].focusIndex;
        }
    };

    /**
     * Restore saved focus state.
     * @param {string} pageId
     */
    FocusManager.prototype.restoreFocusState = function (pageId) {
        var saved = this._focusMemory['__page_' + pageId];
        if (!saved) return false;

        for (var id in saved.groups) {
            if (this._groups[id]) {
                this._groups[id].focusIndex = saved.groups[id];
            }
        }
        if (saved.groupId && this._groups[saved.groupId]) {
            this.focusGroup(saved.groupId, saved.groups[saved.groupId]);
            return true;
        }
        return false;
    };

    /* --------------------------------------------------------
       Internal — Key Handler
       -------------------------------------------------------- */
    FocusManager.prototype._handleKeyDown = function (e) {
        var keyCode = e.keyCode;

        // Debounce rapid key presses
        if (this._debounceTimer) return;
        this._debounceTimer = setTimeout(function () {
            this._debounceTimer = null;
        }.bind(this), TIMING.FOCUS_DEBOUNCE_MS);

        // Determine which group is active
        var activeId = this._dialogTrapping ? this._dialogGroupId : this._activeGroupId;
        var group = this._groups[activeId];
        if (!group || group.items.length === 0) return;

        switch (keyCode) {
            case KC.LEFT:
                e.preventDefault();
                this._navigate(group, 'left');
                break;
            case KC.RIGHT:
                e.preventDefault();
                this._navigate(group, 'right');
                break;
            case KC.UP:
                e.preventDefault();
                this._navigate(group, 'up');
                break;
            case KC.DOWN:
                e.preventDefault();
                this._navigate(group, 'down');
                break;
            case KC.ENTER:
                e.preventDefault();
                this._triggerSelect(group);
                break;
            case KC.BACK:
                e.preventDefault();
                DC.EventBus.emit('navigation:back');
                break;
        }
    };

    /* --------------------------------------------------------
       Internal — Navigation Logic
       -------------------------------------------------------- */
    FocusManager.prototype._navigate = function (group, direction) {
        var layout = group.layout;
        var idx = group.focusIndex;
        var len = group.items.length;
        var cols = group.columns;

        if (layout === 'horizontal') {
            if (direction === 'left') {
                if (idx > 0) this._setFocus(group, idx - 1);
            } else if (direction === 'right') {
                if (idx < len - 1) this._setFocus(group, idx + 1);
            } else if (direction === 'up' || direction === 'down') {
                this._navigateBetweenGroups(direction);
            }
        } else if (layout === 'vertical') {
            if (direction === 'up') {
                if (idx > 0) this._setFocus(group, idx - 1);
                else this._navigateBetweenGroups('up');
            } else if (direction === 'down') {
                if (idx < len - 1) this._setFocus(group, idx + 1);
                else this._navigateBetweenGroups('down');
            } else if (direction === 'left' || direction === 'right') {
                this._navigateBetweenGroups(direction);
            }
        } else if (layout === 'grid') {
            var row = Math.floor(idx / cols);
            var col = idx % cols;
            var totalRows = Math.ceil(len / cols);
            var newIdx = idx;

            if (direction === 'left') {
                if (col > 0) newIdx = idx - 1;
            } else if (direction === 'right') {
                if (col < cols - 1 && idx + 1 < len) newIdx = idx + 1;
            } else if (direction === 'up') {
                if (row > 0) newIdx = idx - cols;
                else this._navigateBetweenGroups('up');
            } else if (direction === 'down') {
                var nextIdx = idx + cols;
                if (nextIdx < len) newIdx = nextIdx;
                else this._navigateBetweenGroups('down');
            }

            if (newIdx !== idx && newIdx >= 0 && newIdx < len) {
                this._setFocus(group, newIdx);
            }
        }
    };

    FocusManager.prototype._navigateBetweenGroups = function (direction) {
        if (this._dialogTrapping) return; // No group navigation in dialog

        var order = this._groupOrder;
        if (order.length === 0) return;

        var currentIdx = order.indexOf(this._activeGroupId);
        if (currentIdx === -1) return;

        var newIdx;
        if (direction === 'up' || direction === 'left') {
            newIdx = currentIdx - 1;
        } else {
            newIdx = currentIdx + 1;
        }

        if (newIdx < 0 || newIdx >= order.length) return;

        var newGroupId = order[newIdx];
        var newGroup = this._groups[newGroupId];
        if (!newGroup || newGroup.items.length === 0) return;

        // Save current group index
        this._groups[this._activeGroupId].focusIndex = this._groups[this._activeGroupId].focusIndex;
        this._focusMemory[this._activeGroupId] = this._groups[this._activeGroupId].focusIndex;

        this.focusGroup(newGroupId);
    };

    /* --------------------------------------------------------
       Internal — Focus Manipulation
       -------------------------------------------------------- */
    FocusManager.prototype._setFocus = function (group, newIndex) {
        // Remove focus from old item
        var oldItem = group.items[group.focusIndex];
        if (oldItem) {
            oldItem.classList.remove('focused');
            oldItem.blur();
        }

        // Set new focus
        group.focusIndex = newIndex;
        this._focusMemory[group.id] = newIndex;
        var newItem = group.items[newIndex];
        if (newItem) {
            newItem.classList.add('focused');
            newItem.focus({ preventScroll: true });

            // Notify for scroll adjustment
            if (group.onScrollNeeded) {
                group.onScrollNeeded(newIndex, newItem);
            }
        }
    };

    FocusManager.prototype._triggerSelect = function (group) {
        var item = group.items[group.focusIndex];
        if (item) {
            DC.EventBus.emit('focus:select', {
                groupId: group.id,
                index: group.focusIndex,
                element: item
            });
        }
    };

    // Export singleton
    DC.FocusManager = new FocusManager();

})(window.DeviceCare = window.DeviceCare || {});
