/* ============================================================
   event-bus.js — Lightweight Pub/Sub Event Bus
   ============================================================ */

(function (DC) {
    'use strict';

    /**
     * EventBus — Decoupled communication between modules.
     * Singleton pattern via DeviceCare.EventBus.
     */
    function EventBus() {
        this._listeners = {};
    }

    /**
     * Subscribe to an event.
     * @param {string} event
     * @param {Function} callback
     * @param {Object} [context] - `this` context for the callback
     * @returns {{ unsubscribe: Function }}
     */
    EventBus.prototype.on = function (event, callback, context) {
        if (!this._listeners[event]) {
            this._listeners[event] = [];
        }
        var entry = { cb: callback, ctx: context || null };
        this._listeners[event].push(entry);

        return {
            unsubscribe: function () {
                this.off(event, callback);
            }.bind(this)
        };
    };

    /**
     * Unsubscribe a specific callback from an event.
     */
    EventBus.prototype.off = function (event, callback) {
        var list = this._listeners[event];
        if (!list) return;
        this._listeners[event] = list.filter(function (entry) {
            return entry.cb !== callback;
        });
    };

    /**
     * Emit an event with optional data.
     */
    EventBus.prototype.emit = function (event, data) {
        var list = this._listeners[event];
        if (!list) return;
        list.forEach(function (entry) {
            entry.cb.call(entry.ctx, data);
        });
    };

    /**
     * Subscribe once — auto-unsubscribe after first invocation.
     */
    EventBus.prototype.once = function (event, callback, context) {
        var self = this;
        function wrapper(data) {
            self.off(event, wrapper);
            callback.call(context || null, data);
        }
        return this.on(event, wrapper, context);
    };

    /**
     * Remove all listeners (useful on page teardown).
     */
    EventBus.prototype.clear = function () {
        this._listeners = {};
    };

    // Singleton instance
    DC.EventBus = new EventBus();

})(window.DeviceCare = window.DeviceCare || {});
