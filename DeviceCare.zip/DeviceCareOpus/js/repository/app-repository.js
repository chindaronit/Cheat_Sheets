/* ============================================================
   app-repository.js — Application Info Repository
   ============================================================
   Provides installed application data.
   On a real Tizen TV this would use tizen.package / tizen.application APIs.
   Here we provide simulated data for the emulator.
   ============================================================ */

(function (DC) {
    'use strict';

    /* ---- Color palette for generated app icons ---- */
    var APP_COLORS = [
        '#C0392B', '#2980B9', '#8E44AD', '#27AE60',
        '#D35400', '#1ABC9C', '#E74C3C', '#3498DB'
    ];

    /* ---- Simulated installed apps ---- */
    var MOCK_APPS = [
        {
            id: 'xstream-play',
            name: 'Xstream Play',
            appSize: 732.00,
            appSizeUnit: 'KB',
            dataSize: 693.94,
            dataSizeUnit: 'KB',
            cacheSize: 0,
            cacheSizeUnit: 'B',
            totalSize: 1.39,
            totalSizeUnit: 'MB',
            color: '#E64A19',
            iconText: 'XP'
        },
        {
            id: 'stay-home-fitness',
            name: 'Stay Home Fitness',
            appSize: 15.20,
            appSizeUnit: 'MB',
            dataSize: 4.64,
            dataSizeUnit: 'MB',
            cacheSize: 0,
            cacheSizeUnit: 'B',
            totalSize: 19.84,
            totalSizeUnit: 'MB',
            color: '#FF8F00',
            iconText: 'SHF'
        },
        {
            id: 'clock-o-clock',
            name: 'clock o clock + music',
            appSize: 620.00,
            appSizeUnit: 'KB',
            dataSize: 159.72,
            dataSizeUnit: 'KB',
            cacheSize: 0,
            cacheSizeUnit: 'B',
            totalSize: 779.72,
            totalSizeUnit: 'KB',
            color: '#FAFAFA',
            iconText: '🕐',
            darkText: true
        },
        {
            id: 'yogifi',
            name: 'YogiFi',
            appSize: 2.50,
            appSizeUnit: 'MB',
            dataSize: 0.71,
            dataSizeUnit: 'MB',
            cacheSize: 0,
            cacheSizeUnit: 'B',
            totalSize: 3.21,
            totalSizeUnit: 'MB',
            color: '#00897B',
            iconText: 'YF'
        },
        {
            id: 'jio-cinema',
            name: 'JioCinema-Shows, Movies ...',
            appSize: 800.00,
            appSizeUnit: 'KB',
            dataSize: 217.76,
            dataSizeUnit: 'KB',
            cacheSize: 0,
            cacheSizeUnit: 'B',
            totalSize: 1017.76,
            totalSizeUnit: 'KB',
            color: '#7B1FA2',
            iconText: 'JC'
        },
        {
            id: 'samsung-experience',
            name: 'Samsung Experience Plus',
            appSize: 2.80,
            appSizeUnit: 'MB',
            dataSize: 0.92,
            dataSizeUnit: 'MB',
            cacheSize: 0,
            cacheSizeUnit: 'B',
            totalSize: 3.72,
            totalSizeUnit: 'MB',
            color: '#1565C0',
            iconText: 'SE'
        }
    ];

    function AppRepository() {
        this._apps = JSON.parse(JSON.stringify(MOCK_APPS));
    }

    /** Get all installed apps */
    AppRepository.prototype.getInstalledApps = function () {
        return this._apps.slice();
    };

    /** Get a single app by ID */
    AppRepository.prototype.getAppById = function (appId) {
        for (var i = 0; i < this._apps.length; i++) {
            if (this._apps[i].id === appId) {
                return JSON.parse(JSON.stringify(this._apps[i]));
            }
        }
        return null;
    };

    /** Clear app data (simulated) */
    AppRepository.prototype.clearAppData = function (appId) {
        for (var i = 0; i < this._apps.length; i++) {
            if (this._apps[i].id === appId) {
                this._apps[i].dataSize = 0;
                this._apps[i].dataSizeUnit = 'B';
                this._recalcTotal(this._apps[i]);
                DC.EventBus.emit('app:dataCleared', { appId: appId });
                return true;
            }
        }
        return false;
    };

    /** Clear app cache (simulated) */
    AppRepository.prototype.clearAppCache = function (appId) {
        for (var i = 0; i < this._apps.length; i++) {
            if (this._apps[i].id === appId) {
                this._apps[i].cacheSize = 0;
                this._apps[i].cacheSizeUnit = 'B';
                this._recalcTotal(this._apps[i]);
                DC.EventBus.emit('app:cacheCleared', { appId: appId });
                return true;
            }
        }
        return false;
    };

    /** Delete app(s) (simulated) */
    AppRepository.prototype.deleteApps = function (appIds) {
        this._apps = this._apps.filter(function (app) {
            return appIds.indexOf(app.id) === -1;
        });
        DC.EventBus.emit('apps:deleted', { appIds: appIds });
    };

    /** Recalculate total size after clearing data/cache */
    AppRepository.prototype._recalcTotal = function (app) {
        var appBytes = this._toBytes(app.appSize, app.appSizeUnit);
        var dataBytes = this._toBytes(app.dataSize, app.dataSizeUnit);
        var cacheBytes = this._toBytes(app.cacheSize, app.cacheSizeUnit);
        var totalBytes = appBytes + dataBytes + cacheBytes;

        if (totalBytes >= 1024 * 1024) {
            app.totalSize = parseFloat((totalBytes / (1024 * 1024)).toFixed(2));
            app.totalSizeUnit = 'MB';
        } else if (totalBytes >= 1024) {
            app.totalSize = parseFloat((totalBytes / 1024).toFixed(2));
            app.totalSizeUnit = 'KB';
        } else {
            app.totalSize = totalBytes;
            app.totalSizeUnit = 'B';
        }
    };

    AppRepository.prototype._toBytes = function (size, unit) {
        switch (unit) {
            case 'GB': return size * 1024 * 1024 * 1024;
            case 'MB': return size * 1024 * 1024;
            case 'KB': return size * 1024;
            default:   return size;
        }
    };

    DC.AppRepository = AppRepository;

})(window.DeviceCare = window.DeviceCare || {});
