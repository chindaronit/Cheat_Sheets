/* ============================================================
   storage-repository.js — Device Storage Repository
   ============================================================ */

(function (DC) {
    'use strict';

    function StorageRepository() {
        this._totalGB = DC.Constants.Storage.TOTAL_GB;
        this._usedGB = 2.12;  // Simulated used storage
    }

    /** Get total storage in GB */
    StorageRepository.prototype.getTotalStorage = function () {
        return this._totalGB;
    };

    /** Get used storage in GB */
    StorageRepository.prototype.getUsedStorage = function () {
        return this._usedGB;
    };

    /** Get available storage in GB */
    StorageRepository.prototype.getAvailableStorage = function () {
        return parseFloat((this._totalGB - this._usedGB).toFixed(2));
    };

    /** Get usage percentage (0-100) */
    StorageRepository.prototype.getUsagePercentage = function () {
        return Math.round((this._usedGB / this._totalGB) * 100);
    };

    /** Reduce used storage when apps are deleted (simulated) */
    StorageRepository.prototype.reduceUsedStorage = function (sizeInMB) {
        var reduction = sizeInMB / 1024; // Convert MB to GB
        this._usedGB = Math.max(0, parseFloat((this._usedGB - reduction).toFixed(2)));
    };

    /** Get health status based on storage usage */
    StorageRepository.prototype.getHealthStatus = function () {
        var pct = this.getUsagePercentage();
        if (pct < 70) return DC.Constants.HealthStatus.GOOD;
        if (pct < 90) return DC.Constants.HealthStatus.WARNING;
        return DC.Constants.HealthStatus.CRITICAL;
    };

    DC.StorageRepository = StorageRepository;

})(window.DeviceCare = window.DeviceCare || {});
