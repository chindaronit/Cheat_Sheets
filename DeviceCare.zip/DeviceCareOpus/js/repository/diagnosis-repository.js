/* ============================================================
   diagnosis-repository.js — Diagnosis Tests Repository
   ============================================================ */

(function (DC) {
    'use strict';

    function DiagnosisRepository() {
        this._tests = DC.Constants.DiagnosisTests.slice();
    }

    /** Get all diagnosis tests */
    DiagnosisRepository.prototype.getTests = function () {
        return this._tests.slice();
    };

    /** Get a test by ID */
    DiagnosisRepository.prototype.getTestById = function (testId) {
        for (var i = 0; i < this._tests.length; i++) {
            if (this._tests[i].id === testId) return this._tests[i];
        }
        return null;
    };

    /** Run a test (simulated) — returns a promise-like callback */
    DiagnosisRepository.prototype.runTest = function (testId, callback) {
        var test = this.getTestById(testId);
        if (!test) {
            callback({ success: false, error: 'Unknown test' });
            return;
        }
        // Simulate async test execution
        setTimeout(function () {
            callback({
                success: true,
                testId: testId,
                result: 'Test completed — no issues detected.'
            });
        }, 1500);
    };

    DC.DiagnosisRepository = DiagnosisRepository;

})(window.DeviceCare = window.DeviceCare || {});
