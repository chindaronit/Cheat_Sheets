/* ============================================================
   app.js — Application Entry Point
   ============================================================
   Bootstraps the DI container, registers routes on the
   NavigationGraph, activates the FocusManager, and
   navigates to the Home page.
   ============================================================ */

(function (DC) {
    'use strict';

    var Routes = DC.Constants.Routes;

    /**
     * Bootstrap the Device Care application.
     */
    function bootstrap() {
        // 1. Build dependency injection container
        var container = DC.DIContainer.build();

        // 2. Get navigation graph
        var navGraph = container.resolve('navGraph');

        // 3. Register routes → page factories
        navGraph.register(Routes.HOME, function () {
            return container.resolve('homePage');
        });

        navGraph.register(Routes.MANAGE_STORAGE, function () {
            return container.resolve('manageStoragePage');
        });

        navGraph.register(Routes.SELF_DIAGNOSIS, function () {
            return container.resolve('selfDiagnosisPage');
        });

        // 4. Activate DPAD focus manager
        DC.FocusManager.activate();

        // 5. Handle dialog back-press (close dialog on BACK)
        DC.EventBus.on('dialog:backPressed', function () {
            // Find any open dialog and close it
            var overlay = document.querySelector('.dialog-overlay.visible');
            if (overlay) {
                DC.FocusManager.unregisterGroup(DC.Constants.FocusGroup.DIALOG_BUTTONS);
                DC.FocusManager.releaseFocusTrap();
                overlay.classList.remove('visible');
                overlay.classList.add('overlay-exit');
                setTimeout(function () {
                    if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
                }, DC.Constants.Timing.DIALOG_ANIM_MS);
            }
        });

        // 6. Register Tizen TV input device keys
        _registerTizenKeys();

        // 7. Initialize navigation — start at Home
        var root = document.getElementById('app-root');
        navGraph.init(root, Routes.HOME);

        console.log('[DeviceCare] Application initialized.');
    }

    /**
     * Register remote control keys with Tizen input device API.
     */
    function _registerTizenKeys() {
        try {
            if (window.tizen && window.tizen.tvinputdevice) {
                var keysToRegister = [
                    'MediaPlay', 'MediaPause', 'MediaStop',
                    'ColorF0Red', 'ColorF1Green', 'ColorF2Yellow', 'ColorF3Blue'
                ];
                keysToRegister.forEach(function (key) {
                    try {
                        tizen.tvinputdevice.registerKey(key);
                    } catch (e) {
                        // Key may not be available on all devices
                    }
                });
            }
        } catch (e) {
            console.log('[DeviceCare] Not running on Tizen device — skipping key registration.');
        }
    }

    // ---- Start the app when DOM is ready ----
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootstrap);
    } else {
        bootstrap();
    }

})(window.DeviceCare = window.DeviceCare || {});
