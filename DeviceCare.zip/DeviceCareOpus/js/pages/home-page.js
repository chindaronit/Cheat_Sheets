/* ============================================================
   home-page.js — Device Care Home Page
   ============================================================
   Displays the health meter, "Start Device Care" button,
   and bottom navigation options:
     Manage Storage | Self-Diagnosis | Request Support
   ============================================================ */

(function (DC) {
    'use strict';

    var Routes = DC.Constants.Routes;
    var FG = DC.Constants.FocusGroup;

    /**
     * @param {Object} deps - Injected dependencies
     * @param {StorageRepository} deps.storageRepo
     */
    function HomePage(deps) {
        this._storageRepo = deps.storageRepo;
        this.el = null;
        this._selectHandler = null;
    }

    /* ---- Lifecycle ---- */

    HomePage.prototype.render = function () {
        var page = document.createElement('div');
        page.className = 'page home-page';
        page.id = 'page-home';

        // Header
        var header = document.createElement('div');
        header.className = 'page-header';
        var title = document.createElement('h1');
        title.className = 'page-title';
        title.textContent = 'Device Care';
        header.appendChild(title);
        page.appendChild(header);

        // Health Section (center)
        var healthSection = document.createElement('div');
        healthSection.className = 'home-health-section';

        var status = this._storageRepo.getHealthStatus();
        var pct = 100 - this._storageRepo.getUsagePercentage(); // inverse: higher = better
        var meter = new DC.HealthMeter({ status: status, percentage: Math.min(pct, 100) });
        healthSection.appendChild(meter.render());

        // Status Label
        var statusLabel = document.createElement('div');
        statusLabel.className = 'health-meter-label';
        statusLabel.textContent = status;
        healthSection.appendChild(statusLabel);

        // Start Device Care button
        var startBtn = document.createElement('button');
        startBtn.className = 'home-start-btn focusable';
        startBtn.setAttribute('tabindex', '0');
        startBtn.setAttribute('data-action', 'start-device-care');
        startBtn.textContent = 'Start Device Care';
        healthSection.appendChild(startBtn);

        page.appendChild(healthSection);

        // Bottom Options Row
        var optionsRow = document.createElement('div');
        optionsRow.className = 'home-options-row';

        var options = [
            { label: 'Manage Storage',  action: Routes.MANAGE_STORAGE },
            { label: 'Self Diagnosis',  action: Routes.SELF_DIAGNOSIS },
            { label: 'Request Support', action: 'request-support', disabled: true }
        ];

        options.forEach(function (opt) {
            var item = document.createElement('div');
            item.className = 'home-option-item focusable' + (opt.disabled ? ' disabled' : '');
            item.setAttribute('tabindex', '0');
            item.setAttribute('data-action', opt.action);
            item.setAttribute('role', 'button');
            item.setAttribute('aria-label', opt.label);
            item.textContent = opt.label;
            optionsRow.appendChild(item);
        });

        page.appendChild(optionsRow);

        this.el = page;
        return page;
    };

    HomePage.prototype.onMount = function () {
        this._registerFocusGroups();
        this._bindEvents();
    };

    HomePage.prototype.onUnmount = function () {
        if (this._selectHandler) {
            DC.EventBus.off('focus:select', this._selectHandler);
        }
        DC.FocusManager.clearGroups();
    };

    /* ---- Focus Registration ---- */

    HomePage.prototype._registerFocusGroups = function () {
        // Start button group (single item)
        var startBtns = this.el.querySelectorAll('.home-start-btn');
        DC.FocusManager.registerGroup(
            FG.HOME_START_BTN,
            Array.prototype.slice.call(startBtns),
            'horizontal'
        );

        // Bottom options
        var optItems = this.el.querySelectorAll('.home-option-item');
        DC.FocusManager.registerGroup(
            FG.HOME_OPTIONS,
            Array.prototype.slice.call(optItems),
            'horizontal'
        );

        // Vertical order: start button → options
        DC.FocusManager.setGroupOrder([FG.HOME_START_BTN, FG.HOME_OPTIONS]);

        // Initial focus on bottom options
        DC.FocusManager.focusGroup(FG.HOME_OPTIONS, 0);
    };

    /* ---- Event Binding ---- */

    HomePage.prototype._bindEvents = function () {
        var self = this;

        this._selectHandler = function (data) {
            var action = data.element.getAttribute('data-action');
            if (!action) return;

            switch (action) {
                case Routes.MANAGE_STORAGE:
                    DC.EventBus.emit('navigate', { route: Routes.MANAGE_STORAGE });
                    break;
                case Routes.SELF_DIAGNOSIS:
                    DC.EventBus.emit('navigate', { route: Routes.SELF_DIAGNOSIS });
                    break;
                case 'start-device-care':
                    // Simulate a device care scan — for now just visual feedback
                    break;
                case 'request-support':
                    // No-op as per requirement
                    break;
            }
        };

        DC.EventBus.on('focus:select', this._selectHandler);
    };

    DC.HomePage = HomePage;

})(window.DeviceCare = window.DeviceCare || {});
