/* ============================================================
   manage-storage-page.js — Manage Storage Page
   ============================================================
   Focus layout (vertical group order):
     [STORAGE_ACTIONS]      — Deselect All / Delete  (horizontal)
     [STORAGE_APPS]         — App cards              (horizontal)
     [STORAGE_VIEW_DETAIL]  — Single View Details btn(horizontal, 1 item)

   Enter on card        → toggle checkbox selection
   Enter on View Detail → open dialog for the card above it
   ============================================================ */

(function (DC) {
    'use strict';

    var FG = DC.Constants.FocusGroup;
    var TIMING = DC.Constants.Timing;

    function ManageStoragePage(deps) {
        this._appRepo = deps.appRepo;
        this._storageRepo = deps.storageRepo;
        this.el = null;
        this._cardInstances = {};
        this._appOrder = [];
        this._selectedIds = {};
        this._dialog = new DC.ViewDetailsDialog();
        this._storageBar = null;
        this._selectHandler = null;
        this._scrollContainer = null;

        /** Single View Details button element */
        this._viewDetailBtn = null;

        /** Tracks which card column the View Details button is under */
        this._focusedCardIndex = 0;
    }

    /* ============================================================
       Render
       ============================================================ */
    ManageStoragePage.prototype.render = function () {
        var page = document.createElement('div');
        page.className = 'page manage-storage-page';
        page.id = 'page-manage-storage';

        // ---- Top Bar ----
        var topBar = document.createElement('div');
        topBar.className = 'storage-top-bar';

        var titleEl = document.createElement('h1');
        titleEl.className = 'page-title';
        titleEl.textContent = 'Manage Storage';
        topBar.appendChild(titleEl);

        this._storageBar = new DC.StorageBar({
            usedGB: this._storageRepo.getUsedStorage(),
            totalGB: this._storageRepo.getTotalStorage()
        });
        topBar.appendChild(this._storageBar.render());
        page.appendChild(topBar);

        // ---- Action Bar ----
        var actionBar = document.createElement('div');
        actionBar.className = 'storage-action-bar';

        var selCount = document.createElement('span');
        selCount.className = 'storage-selection-count';
        selCount.id = 'selection-count';
        selCount.textContent = '0 item(s) selected';
        actionBar.appendChild(selCount);

        var actionBtns = document.createElement('div');
        actionBtns.className = 'storage-action-buttons';

        var deselectBtn = document.createElement('button');
        deselectBtn.className = 'btn btn-secondary focusable';
        deselectBtn.setAttribute('tabindex', '0');
        deselectBtn.setAttribute('data-action', 'deselect-all');
        deselectBtn.textContent = 'Deselect All';
        actionBtns.appendChild(deselectBtn);

        var deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn btn-danger focusable';
        deleteBtn.setAttribute('tabindex', '0');
        deleteBtn.setAttribute('data-action', 'delete-selected');
        deleteBtn.textContent = 'Delete';
        actionBtns.appendChild(deleteBtn);

        actionBar.appendChild(actionBtns);
        page.appendChild(actionBar);

        // ---- App Cards LazyRow ----
        var appsRowWrapper = document.createElement('div');
        appsRowWrapper.className = 'storage-apps-row lazy-row-wrapper';

        var appsScroll = document.createElement('div');
        appsScroll.className = 'storage-apps-scroll';
        appsScroll.id = 'storage-apps-scroll';

        var apps = this._appRepo.getInstalledApps();
        var self = this;
        this._appOrder = [];

        apps.forEach(function (app) {
            var card = new DC.AppCard(app);
            self._cardInstances[app.id] = card;
            self._appOrder.push(app.id);
            appsScroll.appendChild(card.render());
        });

        appsRowWrapper.appendChild(appsScroll);
        page.appendChild(appsRowWrapper);
        this._scrollContainer = appsScroll;

        // ---- Single View Details Button (positioned below focused card) ----
        var vdWrapper = document.createElement('div');
        vdWrapper.className = 'storage-view-detail-wrapper';

        var vdBtn = document.createElement('button');
        vdBtn.className = 'btn-view-detail focusable';
        vdBtn.setAttribute('tabindex', '0');
        vdBtn.setAttribute('data-action', 'view-details');
        vdBtn.textContent = 'View Details';
        vdWrapper.appendChild(vdBtn);

        page.appendChild(vdWrapper);
        this._viewDetailBtn = vdBtn;

        this.el = page;
        return page;
    };

    /* ============================================================
       Lifecycle
       ============================================================ */
    ManageStoragePage.prototype.onMount = function () {
        this._selectedIds = {};
        this._focusedCardIndex = 0;
        this._registerFocusGroups();
        this._bindEvents();
        this._positionViewDetailBtn(0);
    };

    ManageStoragePage.prototype.onUnmount = function () {
        if (this._selectHandler) {
            DC.EventBus.off('focus:select', this._selectHandler);
        }
        if (this._dialog.isOpen()) {
            this._dialog.destroy();
        }
        DC.FocusManager.clearGroups();
    };

    /* ============================================================
       Focus Groups
       ============================================================ */
    ManageStoragePage.prototype._registerFocusGroups = function () {
        var self = this;

        // Action buttons
        var actionBtns = this.el.querySelectorAll('.storage-action-buttons .btn');
        DC.FocusManager.registerGroup(
            FG.STORAGE_ACTIONS,
            Array.prototype.slice.call(actionBtns),
            'horizontal'
        );

        // App cards
        this._registerAppCardsGroup();

        // View Details — single button group
        DC.FocusManager.registerGroup(
            FG.STORAGE_VIEW_DETAIL,
            [this._viewDetailBtn],
            'horizontal'
        );

        DC.FocusManager.setGroupOrder([
            FG.STORAGE_ACTIONS,
            FG.STORAGE_APPS,
            FG.STORAGE_VIEW_DETAIL
        ]);

        DC.FocusManager.focusGroup(FG.STORAGE_APPS, 0);
    };

    ManageStoragePage.prototype._registerAppCardsGroup = function () {
        var cards = this.el.querySelectorAll('.app-card');
        var self = this;

        DC.FocusManager.registerGroup(
            FG.STORAGE_APPS,
            Array.prototype.slice.call(cards),
            'horizontal',
            {
                onScrollNeeded: function (index) {
                    self._focusedCardIndex = index;
                    self._scrollToIndex(index);
                    self._positionViewDetailBtn(index);
                }
            }
        );
    };

    /* ============================================================
       Position the single View Details button below the Nth card
       ============================================================ */
    ManageStoragePage.prototype._positionViewDetailBtn = function (cardIndex) {
        if (!this._viewDetailBtn) return;
        var CARD_W = 240;
        var GAP = 24;
        var offset = cardIndex * (CARD_W + GAP);
        this._viewDetailBtn.style.width = CARD_W + 'px';
        this._viewDetailBtn.style.transform = 'translateX(' + offset + 'px)';

        // Show it when a card or the button itself has focus
        var activeGroup = DC.FocusManager.getActiveGroupId();
        if (activeGroup === FG.STORAGE_APPS || activeGroup === FG.STORAGE_VIEW_DETAIL) {
            this._viewDetailBtn.classList.add('visible');
        }
    };

    /* ============================================================
       LazyRow Scrolling
       ============================================================ */
    ManageStoragePage.prototype._scrollToIndex = function (index) {
        if (!this._scrollContainer) return;

        var CARD_W = 240;
        var GAP = 24;
        var viewportW = 1920 - (96 * 2);
        var total = this._appOrder.length;
        var maxScroll = Math.max(0, (total * (CARD_W + GAP)) - viewportW);

        var target = (index * (CARD_W + GAP)) - (viewportW / 2) + (CARD_W / 2);
        target = Math.max(0, Math.min(target, maxScroll));

        this._scrollContainer.style.transform = 'translateX(-' + target + 'px)';

        // Scroll the view-detail wrapper in sync
        var wrapper = this.el.querySelector('.storage-view-detail-wrapper');
        if (wrapper) {
            wrapper.style.transform = 'translateX(-' + target + 'px)';
        }
    };

    /* ============================================================
       Events
       ============================================================ */
    ManageStoragePage.prototype._bindEvents = function () {
        var self = this;

        this._selectHandler = function (data) {
            // Ignore dialog button events
            if (data.groupId === FG.DIALOG_BUTTONS) return;

            var action = data.element.getAttribute('data-action');
            var appId = data.element.getAttribute('data-app-id');

            if (action === 'deselect-all') {
                self._deselectAll();
                return;
            }
            if (action === 'delete-selected') {
                self._deleteSelected();
                return;
            }
            if (action === 'view-details') {
                // Single View Details button — use tracked card index
                var targetAppId = self._appOrder[self._focusedCardIndex];
                if (targetAppId) self._openViewDetails(targetAppId);
                return;
            }

            // App card Enter — toggle selection
            if (action === 'toggle-select' && appId) {
                self._toggleSelection(appId);
                return;
            }
        };

        DC.EventBus.on('focus:select', this._selectHandler);
    };

    /* ============================================================
       Actions
       ============================================================ */
    ManageStoragePage.prototype._openViewDetails = function (appId) {
        var app = this._appRepo.getAppById(appId);
        if (!app) return;

        var self = this;
        this._dialog.open(app, function onDialogAction(action, id) {
            if (action === 'clearData') {
                self._appRepo.clearAppData(id);
                var u1 = self._appRepo.getAppById(id);
                self._dialog.close();
                setTimeout(function () { self._dialog.open(u1, onDialogAction); },
                    TIMING.DIALOG_ANIM_MS + 50);
            } else if (action === 'clearCache') {
                self._appRepo.clearAppCache(id);
                var u2 = self._appRepo.getAppById(id);
                self._dialog.close();
                setTimeout(function () { self._dialog.open(u2, onDialogAction); },
                    TIMING.DIALOG_ANIM_MS + 50);
            } else if (action === 'close') {
                self._dialog.close();
            }
        });
    };

    ManageStoragePage.prototype._toggleSelection = function (appId) {
        var card = this._cardInstances[appId];
        if (!card) return;

        if (this._selectedIds[appId]) {
            delete this._selectedIds[appId];
            card.setSelected(false);
        } else {
            this._selectedIds[appId] = true;
            card.setSelected(true);
        }
        this._updateSelectionCount();
    };

    ManageStoragePage.prototype._deselectAll = function () {
        var self = this;
        Object.keys(this._selectedIds).forEach(function (id) {
            if (self._cardInstances[id]) self._cardInstances[id].setSelected(false);
        });
        this._selectedIds = {};
        this._updateSelectionCount();
    };

    ManageStoragePage.prototype._deleteSelected = function () {
        var ids = Object.keys(this._selectedIds);
        if (ids.length === 0) return;

        this._appRepo.deleteApps(ids);

        var self = this;
        ids.forEach(function (id) {
            var card = self._cardInstances[id];
            if (card && card.el && card.el.parentNode) {
                card.el.parentNode.removeChild(card.el);
            }
            delete self._cardInstances[id];
            var idx = self._appOrder.indexOf(id);
            if (idx !== -1) self._appOrder.splice(idx, 1);
        });

        this._selectedIds = {};
        this._updateSelectionCount();

        this._registerAppCardsGroup();
        DC.FocusManager.setGroupOrder([
            FG.STORAGE_ACTIONS,
            FG.STORAGE_APPS,
            FG.STORAGE_VIEW_DETAIL
        ]);

        if (this._appOrder.length > 0) {
            DC.FocusManager.focusGroup(FG.STORAGE_APPS, 0);
        } else {
            DC.FocusManager.focusGroup(FG.STORAGE_ACTIONS, 0);
        }

        this._storageBar.update(
            this._storageRepo.getUsedStorage(),
            this._storageRepo.getTotalStorage()
        );
    };

    ManageStoragePage.prototype._updateSelectionCount = function () {
        var count = Object.keys(this._selectedIds).length;
        var el = this.el.querySelector('#selection-count');
        if (el) el.textContent = count + ' item(s) selected';
    };

    DC.ManageStoragePage = ManageStoragePage;

})(window.DeviceCare = window.DeviceCare || {});
