/* ============================================================
   self-diagnosis-page.js — Self Diagnosis Page
   ============================================================
   Displays colored diagnostic test cards in a 3-column grid.
   ============================================================ */

(function (DC) {
    'use strict';

    var FG = DC.Constants.FocusGroup;

    /**
     * @param {Object} deps
     * @param {DiagnosisRepository} deps.diagnosisRepo
     */
    function SelfDiagnosisPage(deps) {
        this._diagnosisRepo = deps.diagnosisRepo;
        this.el = null;
        this._selectHandler = null;
    }

    /* ---- Lifecycle ---- */

    SelfDiagnosisPage.prototype.render = function () {
        var page = document.createElement('div');
        page.className = 'page self-diagnosis-page';
        page.id = 'page-self-diagnosis';

        // Header
        var header = document.createElement('div');
        header.className = 'page-header';
        var title = document.createElement('h1');
        title.className = 'page-title';
        title.textContent = 'Self Diagnosis';
        header.appendChild(title);
        page.appendChild(header);

        // Subtitle
        var subtitle = document.createElement('p');
        subtitle.className = 'diagnosis-subtitle';
        subtitle.textContent = "Use this video test when you experience a problem with your TV's video quality.";
        page.appendChild(subtitle);

        // Cards Grid
        var grid = document.createElement('div');
        grid.className = 'diagnosis-grid';

        var tests = this._diagnosisRepo.getTests();
        tests.forEach(function (test) {
            var card = new DC.DiagnosisCard(test);
            grid.appendChild(card.render());
        });

        page.appendChild(grid);

        this.el = page;
        return page;
    };

    SelfDiagnosisPage.prototype.onMount = function () {
        this._registerFocusGroups();
        this._bindEvents();
    };

    SelfDiagnosisPage.prototype.onUnmount = function () {
        if (this._selectHandler) {
            DC.EventBus.off('focus:select', this._selectHandler);
        }
        DC.FocusManager.clearGroups();
    };

    /* ---- Focus Registration ---- */

    SelfDiagnosisPage.prototype._registerFocusGroups = function () {
        var cards = this.el.querySelectorAll('.diagnosis-card');
        DC.FocusManager.registerGroup(
            FG.DIAGNOSIS_CARDS,
            Array.prototype.slice.call(cards),
            'grid',
            { columns: 3 }
        );

        DC.FocusManager.setGroupOrder([FG.DIAGNOSIS_CARDS]);
        DC.FocusManager.focusGroup(FG.DIAGNOSIS_CARDS, 0);
    };

    /* ---- Event Binding ---- */

    SelfDiagnosisPage.prototype._bindEvents = function () {
        var self = this;

        this._selectHandler = function (data) {
            if (data.groupId !== FG.DIAGNOSIS_CARDS) return;

            var testId = data.element.getAttribute('data-test-id');
            if (!testId) return;

            // Scale animation on select (visual feedback only)
            data.element.style.transform = 'scale(1.1)';
            setTimeout(function () {
                data.element.style.transform = '';
            }, 200);
        };

        DC.EventBus.on('focus:select', this._selectHandler);
    };

    DC.SelfDiagnosisPage = SelfDiagnosisPage;

})(window.DeviceCare = window.DeviceCare || {});
