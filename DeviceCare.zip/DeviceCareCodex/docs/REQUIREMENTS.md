# Functional and Non-Functional Requirements

## Functional Requirements

1. Home Screen
- FR-1: Show title `Device Care` in top-left region.
- FR-2: Show semi-circular health meter in center with qualitative status label.
- FR-3: Show three options: `Manage Storage`, `Self-Diagnosis`, `Request Support`.
- FR-4: Enter on `Manage Storage` navigates to Manage Storage screen.
- FR-5: Enter on `Self-Diagnosis` navigates to Self-Diagnosis screen.
- FR-6: Enter on `Request Support` performs no action.

2. Manage Storage
- FR-7: Show `Manage Storage` title.
- FR-8: Show total used/available storage with horizontal progress bar.
- FR-9: Show selected item count.
- FR-10: Provide `Deselect All` action.
- FR-11: Provide `Delete` action for selected apps.
- FR-12: Show installed app cards with app visual, name, and size.
- FR-13: Show `View Details` button under currently focused app card.
- FR-14: Enter on app card toggles selection.
- FR-15: Enter on `View Details` opens dialog for focused app.

3. View Details Dialog
- FR-16: Show dialog title `View Details`.
- FR-17: Show metrics: App, Data, Cache, Total.
- FR-18: Provide `Clear Data`, `Clear Cache`, `Close` actions.
- FR-19: `Clear Data` resets selected app data value.
- FR-20: `Clear Cache` resets selected app cache value.
- FR-21: `Close` dismisses dialog and restores previous focus.

4. Self-Diagnosis
- FR-22: Show `Self-Diagnosis` title.
- FR-23: Show diagnosis tiles:
  - Video Test
  - Picture Test
  - Sound Test
  - HDMI Troubleshooting
  - Signal Information
  - Smart Hub Connection Test
  - Reset Smart Hub
- FR-24: Focused diagnosis tile scales and glows.

5. Navigation and Input
- FR-25: DPAD navigation must work across all focusable controls.
- FR-26: Enter must trigger focused control action.
- FR-27: Back key closes dialog first, then navigates back by route history.
- FR-28: App should remember focus position when returning to a previous screen.

## Non-Functional Requirements

1. TV UX and Accessibility
- NFR-1: No touch dependency; remote-only operation.
- NFR-2: 10-foot UI readability with large typography and spacing.
- NFR-3: Overscan-safe margins must protect edge content visibility.
- NFR-4: Focus state must always be visible and high contrast.

2. Performance
- NFR-5: App list rendering should support windowed virtualization (LazyRow-style) for smooth horizontal navigation.
- NFR-6: State updates should re-render only affected screen parts.

3. Maintainability
- NFR-7: Use modular architecture with clear separation of UI, domain state, and device APIs.
- NFR-8: Dependency creation must be centralized in DI container.
- NFR-9: Navigation graph must be explicit and route-driven.

4. Reliability
- NFR-10: Storage operations should remain safe when Tizen APIs are unavailable by using service fallback behavior.
- NFR-11: Back navigation behavior must be deterministic across screens and dialog state.

5. Portability
- NFR-12: Project should open and build in Tizen Studio without source code modifications.