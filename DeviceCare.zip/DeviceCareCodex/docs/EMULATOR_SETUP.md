# TV Emulator Setup Guide

## 1. Open Package Manager

- Start Tizen Studio.
- Open `Tools -> Package Manager`.

## 2. Add TV Extension Repository

Use the extension repository URL:

`https://download.tizen.org/sdk/extensions/tv_extensions/`

## 3. Install TV Extension Packages

Install the package group:

`TV-SAMSUNG-Public`

This group contains:
- TV web app development add-ons
- TV profile extension
- TV emulator packages and dependencies

## 4. Create Emulator Instance

- Open `Tools -> Emulator Manager`.
- Create a new TV emulator instance.
- Start the emulator and confirm ADB connectivity in Device Manager.

## 5. Deploy Device Care App

- Build and package the app (`.wgt`).
- Run directly from Tizen Studio (Run As Tizen Web Application) or install via CLI.

## 6. Troubleshooting

- If TV profile is not visible, re-check that `TV-SAMSUNG-Public` is fully installed.
- If emulator fails to start, verify virtualization support (Intel VT-x / AMD-V).
- If signing fails, configure certificate profile in `Tools -> Certificate Manager`.