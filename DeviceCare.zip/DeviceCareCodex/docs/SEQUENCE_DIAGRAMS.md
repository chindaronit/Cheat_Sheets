# Sequence Diagrams

## 1. Home -> Manage Storage Navigation

```mermaid
sequenceDiagram
  participant User
  participant Focus as FocusManager
  participant Home as HomeScreen
  participant Router
  participant App
  participant Manage as ManageStorageScreen

  User->>Focus: DPAD to Manage Storage
  User->>Focus: Enter
  Focus->>Home: onEnter(home-manage)
  Home->>Router: navigate(manage-storage)
  Router->>App: route change event
  App->>Home: unmount()
  App->>Manage: mount(restoreFocusKey)
  Manage->>Focus: requestFocus(manage-card-0)
```

## 2. Manage Storage -> View Details -> Clear Cache

```mermaid
sequenceDiagram
  participant User
  participant Focus as FocusManager
  participant Manage as ManageStorageScreen
  participant Dialog as DetailsDialog
  participant Repo as DeviceCareRepository

  User->>Focus: DPAD to card and View Details
  User->>Focus: Enter on View Details
  Focus->>Manage: onEnter(manage-view-details)
  Manage->>Dialog: open(appId)
  Dialog->>Focus: register dialog focus nodes

  User->>Focus: Enter on Clear Cache
  Focus->>Dialog: onEnter(dialog-clear-cache)
  Dialog->>Repo: clearAppCache(appId)
  Repo-->>Manage: state update
  Manage->>Dialog: refresh()

  User->>Focus: Enter on Close
  Focus->>Dialog: onEnter(dialog-close)
  Dialog->>Manage: close + restore focus
```

## 3. Delete Selected Apps

```mermaid
sequenceDiagram
  participant User
  participant Focus as FocusManager
  participant Manage as ManageStorageScreen
  participant Repo as DeviceCareRepository
  participant Service as TizenStorageService

  User->>Focus: Enter on app cards to select
  Focus->>Manage: onEnter(manage-card-*)
  Manage->>Repo: toggleSelection(appId)
  Repo-->>Manage: state snapshot update

  User->>Focus: Enter on Delete
  Focus->>Manage: onEnter(manage-delete)
  Manage->>Repo: deleteSelectedApplications()
  Repo->>Service: uninstallApplication(appId)*
  Service-->>Repo: success/failure
  Repo-->>Manage: updated app list
  Manage-->>User: toast "N app(s) removed"
```

## 4. Back Handling

```mermaid
sequenceDiagram
  participant User
  participant App
  participant Screen
  participant Router

  User->>App: Back key
  App->>Screen: handleBack()
  alt Dialog open on screen
    Screen-->>App: true (consumed)
  else No in-screen back action
    Screen-->>App: false
    App->>Router: back()
    alt has route history
      Router-->>App: true
    else no history
      Router-->>App: false
      App-->>User: exits current app
    end
  end
```