# Architecture

## 1. Layered Architecture

```mermaid
flowchart TD
  A[App Bootstrap\njs/main.js] --> B[Application Orchestrator\njs/app/App.js]

  B --> C[Router\njs/core/Router.js]
  B --> D[FocusManager\njs/core/FocusManager.js]
  B --> E[Screens]

  E --> E1[HomeScreen]
  E --> E2[ManageStorageScreen]
  E --> E3[SelfDiagnosisScreen]

  E2 --> F[DetailsDialog]
  E2 --> G[VirtualRow\nLazyRow-style windowing]

  E --> H[DeviceCareRepository]
  H --> I[TizenStorageService]

  B --> J[DIContainer]
  J --> C
  J --> D
  J --> H
  J --> I
```

## 2. Dependency Injection

`DIContainer` wires singleton dependencies:
- `FocusManager`
- `Router`
- `TizenStorageService`
- `DeviceCareRepository`

Screens receive dependencies through constructor injection from `App`.

## 3. Navigation

- Route constants defined in `js/constants/routes.js`
- Route transitions validated against `NavigationGraph`
- Back stack managed in `Router.history`
- Per-route focus memory managed in `App.focusMemory`

## 4. Focus Model

- Focus registry key format:
  - `home-*`
  - `manage-*`
  - `diag-*`
  - `dialog-*`
- `FocusManager` supports:
  - Explicit neighbors
  - Spatial fallback resolution
  - Enter callback dispatch
- Focus restoration on route return is automatic.

## 5. Repository Layer

`DeviceCareRepository` responsibilities:
- Holds app/storage state.
- Provides immutable snapshots for UI rendering.
- Implements selection, delete, clear data/cache mutations.
- Emits state updates to subscribers.

`TizenStorageService` responsibilities:
- Tizen API integration boundary.
- Async methods for app list/uninstall/maintenance operations.

## 6. Class Diagram

```mermaid
classDiagram
  class App {
    -DIContainer container
    -Router router
    -FocusManager focusManager
    -DeviceCareRepository repository
    -Map~string,string~ focusMemory
    +start()
    +handleKeyDown(event)
    +handleTizenKey(event)
  }

  class DIContainer {
    +registerSingleton(token, factory)
    +registerFactory(token, factory)
    +resolve(token)
  }

  class Router {
    -string currentRoute
    -Array history
    +navigate(route, params)
    +back(params)
    +subscribe(listener)
  }

  class FocusManager {
    -Map registry
    -string activeKey
    +register(node)
    +requestFocus(key)
    +move(direction)
    +activate()
    +clear()
  }

  class DeviceCareRepository {
    -Array apps
    -Set listeners
    +getStateSnapshot()
    +toggleSelection(appId)
    +clearSelection()
    +deleteSelectedApplications()
    +clearAppData(appId)
    +clearAppCache(appId)
    +subscribe(listener)
  }

  class TizenStorageService {
    +getInstalledApplications()
    +uninstallApplication(appId)
    +clearData(appId)
    +clearCache(appId)
  }

  class HomeScreen
  class ManageStorageScreen
  class SelfDiagnosisScreen
  class DetailsDialog
  class VirtualRow

  App --> DIContainer
  App --> Router
  App --> FocusManager
  App --> DeviceCareRepository
  DeviceCareRepository --> TizenStorageService
  App --> HomeScreen
  App --> ManageStorageScreen
  App --> SelfDiagnosisScreen
  ManageStorageScreen --> DetailsDialog
  ManageStorageScreen --> VirtualRow
  ManageStorageScreen --> DeviceCareRepository
  HomeScreen --> FocusManager
  SelfDiagnosisScreen --> FocusManager
```