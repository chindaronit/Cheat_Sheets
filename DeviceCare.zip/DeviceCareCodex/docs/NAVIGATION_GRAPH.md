# Navigation Graph

```mermaid
stateDiagram-v2
  [*] --> Home

  Home --> ManageStorage: Manage Storage (Enter)
  Home --> SelfDiagnosis: Self-Diagnosis (Enter)
  Home --> Home: Request Support (No-op)

  ManageStorage --> Home: Back
  SelfDiagnosis --> Home: Back

  ManageStorage --> DetailsDialog: View Details
  DetailsDialog --> ManageStorage: Close / Back
```

## Route IDs

- `home`
- `manage-storage`
- `self-diagnosis`

## Focus Restoration Rules

- When leaving a route, currently focused key is stored.
- Returning to the route restores the last focused element if still available.
- If target no longer exists (for example deleted app card), fallback focus is applied.