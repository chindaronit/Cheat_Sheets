import { KeyCodes } from "../../constants/keyCodes.js";
import { UIConstants } from "../../constants/uiConstants.js";
import { VirtualRow } from "../../core/VirtualRow.js";
import { DetailsDialog } from "../components/DetailsDialog.js";
import { formatStorage } from "../../utils/formatters.js";
import { showToast } from "../../utils/dom.js";

export class ManageStorageScreen {
  constructor({ repository, focusManager }) {
    this.repository = repository;
    this.focusManager = focusManager;

    this.host = null;
    this.unsubscribeRepository = null;
    this.focusInListener = null;

    this.virtualRow = null;
    this.dialog = null;

    this.apps = [];
    this.cursorIndex = 0;
    this.visibleRange = { start: 0, end: 0 };

    this.staticKeys = [];
    this.dynamicKeys = [];
    this.elements = {};
  }

  mount(host, { restoreFocusKey } = {}) {
    this.host = host;
    this.focusManager.clear();

    this._renderShell();
    this._cacheElements();

    this.virtualRow = new VirtualRow({
      trackElement: this.elements.track,
      itemWidth: UIConstants.APP_CARD_WIDTH,
      gap: UIConstants.APP_CARD_GAP,
      windowSize: UIConstants.APP_ROW_WINDOW_SIZE,
      renderItem: (item, index) => this._createAppCard(item, index)
    });

    this.dialog = new DetailsDialog({
      focusManager: this.focusManager,
      host: this.host
    });

    this._registerStaticFocusables();
    this.unsubscribeRepository = this.repository.subscribe(() => {
      this._refreshFromRepository();
    });

    this.focusInListener = () => {
      this._updateViewDetailsVisibility();
    };
    this.host.addEventListener("focusin", this.focusInListener);

    this._refreshFromRepository();
    this._focusByRestoreKey(restoreFocusKey);
  }

  unmount() {
    if (this.unsubscribeRepository) {
      this.unsubscribeRepository();
      this.unsubscribeRepository = null;
    }

    if (this.dialog && this.dialog.isOpen()) {
      this.dialog.close(false);
    }

    if (this.focusInListener) {
      this.host.removeEventListener("focusin", this.focusInListener);
      this.focusInListener = null;
    }

    for (const key of [...this.dynamicKeys, ...this.staticKeys]) {
      this.focusManager.unregister(key);
    }

    this.dynamicKeys = [];
    this.staticKeys = [];

    if (this.host) {
      this.host.innerHTML = "";
    }
  }

  getFocusedKey() {
    const activeKey = this.focusManager.getActiveKey();
    if (activeKey && activeKey.startsWith("manage-")) {
      return activeKey;
    }

    return this.apps.length ? `manage-card-${this.cursorIndex}` : "manage-deselect";
  }

  handleBack() {
    if (this.dialog && this.dialog.isOpen()) {
      this.dialog.close();
      return true;
    }

    return false;
  }

  onKeyDown(event) {
    const keyCode = event.keyCode;
    const activeKey = this.focusManager.getActiveKey() || "";

    if (this.dialog && this.dialog.isOpen()) {
      if (keyCode === KeyCodes.ESCAPE || keyCode === KeyCodes.BACKSPACE || keyCode === KeyCodes.TIZEN_BACK) {
        this.dialog.close();
        return true;
      }

      return false;
    }

    if (activeKey.startsWith("manage-card-")) {
      if (keyCode === KeyCodes.LEFT) {
        return this._moveCursor(-1);
      }

      if (keyCode === KeyCodes.RIGHT) {
        return this._moveCursor(1);
      }

      if (keyCode === KeyCodes.DOWN && this.apps.length) {
        this.focusManager.requestFocus("manage-view-details");
        return true;
      }

      if (keyCode === KeyCodes.UP) {
        this.focusManager.requestFocus("manage-deselect");
        return true;
      }
    }

    if (activeKey === "manage-view-details") {
      if (keyCode === KeyCodes.LEFT) {
        return this._moveCursor(-1, "manage-view-details");
      }

      if (keyCode === KeyCodes.RIGHT) {
        return this._moveCursor(1, "manage-view-details");
      }

      if (keyCode === KeyCodes.UP) {
        this.focusManager.requestFocus(`manage-card-${this.cursorIndex}`);
        return true;
      }
    }

    if ((activeKey === "manage-deselect" || activeKey === "manage-delete") && keyCode === KeyCodes.DOWN && this.apps.length) {
      this.focusManager.requestFocus(`manage-card-${this.cursorIndex}`);
      return true;
    }

    return false;
  }

  _renderShell() {
    this.host.innerHTML = `
      <section class="screen manage-screen">
        <header class="manage-header">
          <h1 class="screen-title">Manage Storage</h1>

          <div class="storage-summary">
            <div class="storage-line">
              <span>Used <span id="used-storage"></span></span>
              <span>Available <span id="available-storage"></span></span>
            </div>
            <div class="storage-progress">
              <div id="storage-progress-fill" class="storage-progress-fill"></div>
            </div>
          </div>
        </header>

        <section class="manage-actions">
          <p id="selected-count" class="selected-info">0 item(s) selected</p>
          <div class="manage-buttons">
            <button id="manage-deselect-btn" class="manage-mini-btn focusable" type="button">Deselect All</button>
            <button id="manage-delete-btn" class="manage-mini-btn focusable" type="button">Delete</button>
          </div>
        </section>

        <section class="apps-row-shell">
          <div id="apps-empty" class="empty-state" hidden>No installed apps found.</div>
          <div id="apps-viewport" class="apps-row-viewport">
            <div id="apps-track" class="apps-row-track"></div>
          </div>
          <div class="view-details-area">
            <button id="manage-view-details-btn" class="view-details-btn focusable" type="button">View Details</button>
          </div>
        </section>
      </section>
    `;
  }

  _cacheElements() {
    this.elements = {
      usedStorage: this.host.querySelector("#used-storage"),
      availableStorage: this.host.querySelector("#available-storage"),
      progressFill: this.host.querySelector("#storage-progress-fill"),
      selectedCount: this.host.querySelector("#selected-count"),
      deselectButton: this.host.querySelector("#manage-deselect-btn"),
      deleteButton: this.host.querySelector("#manage-delete-btn"),
      emptyState: this.host.querySelector("#apps-empty"),
      viewport: this.host.querySelector("#apps-viewport"),
      track: this.host.querySelector("#apps-track"),
      viewDetailsButton: this.host.querySelector("#manage-view-details-btn")
    };
  }

  _registerStaticFocusables() {
    this.staticKeys = ["manage-deselect", "manage-delete"];

    this.focusManager.register({
      key: "manage-deselect",
      element: this.elements.deselectButton,
      neighbors: {
        up: "manage-deselect",
        down: "manage-card-0",
        left: "manage-deselect",
        right: "manage-delete"
      },
      onEnter: () => {
        this.repository.clearSelection();
      }
    });

    this.focusManager.register({
      key: "manage-delete",
      element: this.elements.deleteButton,
      neighbors: {
        up: "manage-delete",
        down: "manage-card-0",
        left: "manage-deselect",
        right: "manage-delete"
      },
      onEnter: async () => {
        const selectedCount = this.repository.getSelectedCount();
        if (!selectedCount) {
          return;
        }

        const deleted = await this.repository.deleteSelectedApplications();
        showToast(this.host, `${deleted} app(s) removed.`);
      }
    });
  }

  _refreshFromRepository() {
    const snapshot = this.repository.getStateSnapshot();
    this.apps = snapshot.apps;

    if (this.cursorIndex > this.apps.length - 1) {
      this.cursorIndex = Math.max(0, this.apps.length - 1);
    }

    this.elements.usedStorage.textContent = formatStorage(snapshot.storage.usedMb);
    this.elements.availableStorage.textContent = formatStorage(snapshot.storage.availableMb);
    this.elements.progressFill.style.width = `${snapshot.storage.usedPercent.toFixed(2)}%`;

    this.elements.selectedCount.textContent = `${snapshot.selectedCount} item(s) selected`;

    this._setButtonState(this.elements.deleteButton, snapshot.selectedCount === 0);
    this._setButtonState(this.elements.deselectButton, snapshot.selectedCount === 0);

    this._renderAppRow();

    if (this.dialog && this.dialog.isOpen()) {
      this.dialog.refresh();
    }
  }

  _setButtonState(button, disabled) {
    button.classList.toggle("is-disabled", disabled);
    button.setAttribute("aria-disabled", disabled ? "true" : "false");
  }

  _renderAppRow() {
    this._unregisterDynamicFocusables();

    if (!this.apps.length) {
      this.elements.emptyState.hidden = false;
      this.elements.viewport.hidden = true;
      this.elements.viewDetailsButton.classList.add("is-hidden");
      this.focusManager.updateNeighbors("manage-deselect", {
        up: "manage-deselect",
        down: "manage-deselect",
        left: "manage-deselect",
        right: "manage-delete"
      });
      this.focusManager.updateNeighbors("manage-delete", {
        up: "manage-delete",
        down: "manage-delete",
        left: "manage-deselect",
        right: "manage-delete"
      });
      return;
    }

    this.elements.emptyState.hidden = true;
    this.elements.viewport.hidden = false;

    this.virtualRow.setItems(this.apps);
    this.virtualRow.setCursorIndex(this.cursorIndex);
    this.visibleRange = this.virtualRow.render();

    for (let index = this.visibleRange.start; index < this.visibleRange.end; index += 1) {
      const cardElement = this.elements.track.querySelector(`[data-index='${index}']`);
      if (!cardElement) {
        continue;
      }

      const focusKey = `manage-card-${index}`;
      this.dynamicKeys.push(focusKey);

      this.focusManager.register({
        key: focusKey,
        element: cardElement,
        neighbors: {
          up: "manage-deselect",
          down: "manage-view-details",
          left: focusKey,
          right: focusKey
        },
        onEnter: () => {
          const app = this.apps[index];
          if (app) {
            this.repository.toggleSelection(app.id);
          }
        }
      });
    }

    this.dynamicKeys.push("manage-view-details");
    this.focusManager.register({
      key: "manage-view-details",
      element: this.elements.viewDetailsButton,
      neighbors: {
        up: `manage-card-${this.cursorIndex}`,
        down: "manage-view-details",
        left: "manage-view-details",
        right: "manage-view-details"
      },
      onEnter: () => {
        this._openDetailsForCursor();
      }
    });

    this.focusManager.updateNeighbors("manage-deselect", {
      up: "manage-deselect",
      down: `manage-card-${this.cursorIndex}`,
      left: "manage-deselect",
      right: "manage-delete"
    });

    this.focusManager.updateNeighbors("manage-delete", {
      up: "manage-delete",
      down: `manage-card-${this.cursorIndex}`,
      left: "manage-deselect",
      right: "manage-delete"
    });

    this._updateViewDetailsButtonPosition();
    this._updateViewDetailsVisibility();
  }

  _createAppCard(app, index) {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "app-card focusable";
    card.dataset.index = String(index);

    const banner = document.createElement("div");
    banner.className = "app-card-banner";
    banner.style.background = `linear-gradient(140deg, ${app.gradientA}, ${app.gradientB})`;

    const checkbox = document.createElement("div");
    checkbox.className = `app-check ${app.selected ? "is-selected" : ""}`;

    const logo = document.createElement("div");
    logo.className = "app-logo-chip";
    logo.textContent = app.logo;

    banner.appendChild(checkbox);
    banner.appendChild(logo);

    const footer = document.createElement("div");
    footer.className = "app-card-footer";

    const name = document.createElement("div");
    name.className = "app-name";
    name.textContent = app.name;

    const size = document.createElement("div");
    size.className = "app-size";
    size.textContent = formatStorage(app.totalMb);

    footer.appendChild(name);
    footer.appendChild(size);

    card.appendChild(banner);
    card.appendChild(footer);

    return card;
  }

  _updateViewDetailsButtonPosition() {
    if (!this.apps.length) {
      return;
    }

    const visibleOffset = this.cursorIndex - this.visibleRange.start;
    const x = visibleOffset * (UIConstants.APP_CARD_WIDTH + UIConstants.APP_CARD_GAP);
    this.elements.viewDetailsButton.style.transform = `translateX(${x}px)`;
  }

  _updateViewDetailsVisibility() {
    const active = this.focusManager.getActiveKey() || "";
    const shouldShow = active.startsWith("manage-card-") || active === "manage-view-details";
    this.elements.viewDetailsButton.classList.toggle("is-hidden", !shouldShow);
  }

  _moveCursor(delta, retainFocusKey = null) {
    if (!this.apps.length) {
      return false;
    }

    const nextIndex = Math.max(0, Math.min(this.cursorIndex + delta, this.apps.length - 1));
    if (nextIndex === this.cursorIndex) {
      return true;
    }

    this.cursorIndex = nextIndex;
    this._renderAppRow();

    if (retainFocusKey === "manage-view-details") {
      this.focusManager.requestFocus("manage-view-details");
    } else {
      this.focusManager.requestFocus(`manage-card-${this.cursorIndex}`);
    }

    return true;
  }

  _openDetailsForCursor() {
    const app = this.apps[this.cursorIndex];
    if (!app) {
      return;
    }

    this.dialog.open({
      appId: app.id,
      getDetails: (appId) => this.repository.getAppDetails(appId),
      onClearData: async (appId) => {
        await this.repository.clearAppData(appId);
      },
      onClearCache: async (appId) => {
        await this.repository.clearAppCache(appId);
      },
      onClose: () => {
        this._updateViewDetailsVisibility();
      },
      returnFocusKey: "manage-view-details"
    });
  }

  _focusByRestoreKey(restoreFocusKey) {
    if (!this.apps.length) {
      this.focusManager.requestFocus("manage-deselect");
      return;
    }

    if (restoreFocusKey && restoreFocusKey.startsWith("manage-card-")) {
      const parsed = Number.parseInt(restoreFocusKey.replace("manage-card-", ""), 10);
      if (Number.isInteger(parsed) && parsed >= 0 && parsed < this.apps.length) {
        this.cursorIndex = parsed;
        this._renderAppRow();
      }
    }

    if (!restoreFocusKey || !this.focusManager.requestFocus(restoreFocusKey)) {
      this.focusManager.requestFocus(`manage-card-${this.cursorIndex}`);
    }
  }

  _unregisterDynamicFocusables() {
    for (const key of this.dynamicKeys) {
      this.focusManager.unregister(key);
    }

    this.dynamicKeys = [];
  }
}
