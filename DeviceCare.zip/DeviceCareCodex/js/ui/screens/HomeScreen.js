import { Routes } from "../../constants/routes.js";
import { createSemiCircularMeter } from "../components/SemiCircularMeter.js";
import { showToast } from "../../utils/dom.js";

export class HomeScreen {
  constructor({ router, repository, focusManager }) {
    this.router = router;
    this.repository = repository;
    this.focusManager = focusManager;
    this.host = null;
    this.registeredKeys = [];
  }

  mount(host, { restoreFocusKey } = {}) {
    this.host = host;
    this.focusManager.clear();

    const health = this.repository.getHealth();

    this.host.innerHTML = `
      <section class="screen home-screen">
        <h1 class="screen-title">Device Care</h1>

        <div class="home-center">
          <div id="meter-slot"></div>
          <button id="home-start" class="btn home-action focusable" type="button">Start Device Care</button>
        </div>

        <div class="home-options">
          <button id="home-manage" class="home-option focusable" type="button">Manage Storage</button>
          <button id="home-diagnosis" class="home-option focusable" type="button">Self-Diagnosis</button>
          <button id="home-support" class="home-option focusable" type="button">Request Support</button>
        </div>
      </section>
    `;

    const meterNode = createSemiCircularMeter({ score: health.score, label: health.label });
    this.host.querySelector("#meter-slot").appendChild(meterNode);

    this._registerFocusables();

    if (!restoreFocusKey || !this.focusManager.requestFocus(restoreFocusKey)) {
      this.focusManager.requestFocus("home-manage");
    }
  }

  unmount() {
    for (const key of this.registeredKeys) {
      this.focusManager.unregister(key);
    }

    this.registeredKeys = [];
    if (this.host) {
      this.host.innerHTML = "";
    }
  }

  getFocusedKey() {
    const activeKey = this.focusManager.getActiveKey();
    return activeKey && activeKey.startsWith("home-") ? activeKey : "home-manage";
  }

  handleBack() {
    return false;
  }

  onKeyDown(_event) {
    return false;
  }

  _registerFocusables() {
    const register = (config) => {
      this.registeredKeys.push(config.key);
      this.focusManager.register(config);
    };

    register({
      key: "home-start",
      element: this.host.querySelector("#home-start"),
      neighbors: {
        up: "home-start",
        down: "home-manage",
        left: "home-start",
        right: "home-start"
      },
      onEnter: () => {
        showToast(this.host, "Device optimization check complete.");
      }
    });

    register({
      key: "home-manage",
      element: this.host.querySelector("#home-manage"),
      neighbors: {
        up: "home-start",
        down: "home-manage",
        left: "home-manage",
        right: "home-diagnosis"
      },
      onEnter: () => {
        this.router.navigate(Routes.MANAGE_STORAGE);
      }
    });

    register({
      key: "home-diagnosis",
      element: this.host.querySelector("#home-diagnosis"),
      neighbors: {
        up: "home-start",
        down: "home-diagnosis",
        left: "home-manage",
        right: "home-support"
      },
      onEnter: () => {
        this.router.navigate(Routes.SELF_DIAGNOSIS);
      }
    });

    register({
      key: "home-support",
      element: this.host.querySelector("#home-support"),
      neighbors: {
        up: "home-start",
        down: "home-support",
        left: "home-diagnosis",
        right: "home-support"
      },
      onEnter: () => {
        // Intentionally no-op until support workflow is implemented.
      }
    });
  }
}
