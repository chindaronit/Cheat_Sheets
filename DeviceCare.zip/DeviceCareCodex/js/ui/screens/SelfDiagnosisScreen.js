import { showToast } from "../../utils/dom.js";

const diagnosisTiles = [
  { id: "video-test", title: "Video Test", background: "linear-gradient(130deg, #c9524e, #ef7f44)" },
  { id: "picture-test", title: "Picture Test", background: "linear-gradient(130deg, #dd4f9a, #ff77a8)" },
  { id: "sound-test", title: "Sound Test", background: "linear-gradient(130deg, #f2b977, #ffdfaa)" },
  { id: "hdmi", title: "HDMI Troubleshooting", background: "linear-gradient(130deg, #3852cc, #2946b0)" },
  { id: "signal-info", title: "Signal Information", background: "linear-gradient(130deg, #5cb6de, #79daf9)" },
  { id: "hub-test", title: "Smart Hub Connection Test", background: "linear-gradient(130deg, #1d56cf, #0b30a5)" },
  { id: "reset-hub", title: "Reset Smart Hub", background: "linear-gradient(130deg, #3e7eb6, #4a8cc8)" }
];

export class SelfDiagnosisScreen {
  constructor({ focusManager }) {
    this.focusManager = focusManager;
    this.host = null;
    this.registeredKeys = [];
  }

  mount(host, { restoreFocusKey } = {}) {
    this.host = host;
    this.focusManager.clear();

    this.host.innerHTML = `
      <section class="screen self-screen">
        <h1 class="screen-title">Self-Diagnosis</h1>
        <p class="self-caption">Use tests when you experience a problem with TV picture, audio, or connectivity.</p>
        <div id="diagnosis-grid" class="diagnosis-grid"></div>
      </section>
    `;

    const grid = this.host.querySelector("#diagnosis-grid");

    diagnosisTiles.forEach((tile, index) => {
      const button = document.createElement("button");
      button.id = `diag-${index}`;
      button.type = "button";
      button.className = `diag-card focusable ${index === 6 ? "is-row-last" : ""}`;
      button.style.background = tile.background;
      button.textContent = tile.title;
      grid.appendChild(button);
    });

    this._registerFocusables();

    if (!restoreFocusKey || !this.focusManager.requestFocus(restoreFocusKey)) {
      this.focusManager.requestFocus("diag-0");
    }
  }

  unmount() {
    for (const key of this.registeredKeys) {
      this.focusManager.unregister(key);
    }

    this.registeredKeys = [];
    if (this.host) {
      this.host.innerHTML = "";
    }
  }

  getFocusedKey() {
    const activeKey = this.focusManager.getActiveKey();
    return activeKey && activeKey.startsWith("diag-") ? activeKey : "diag-0";
  }

  handleBack() {
    return false;
  }

  onKeyDown(_event) {
    return false;
  }

  _registerFocusables() {
    const neighborMap = {
      "diag-0": { left: "diag-0", right: "diag-1", up: "diag-0", down: "diag-3" },
      "diag-1": { left: "diag-0", right: "diag-2", up: "diag-1", down: "diag-4" },
      "diag-2": { left: "diag-1", right: "diag-2", up: "diag-2", down: "diag-5" },
      "diag-3": { left: "diag-3", right: "diag-4", up: "diag-0", down: "diag-6" },
      "diag-4": { left: "diag-3", right: "diag-5", up: "diag-1", down: "diag-6" },
      "diag-5": { left: "diag-4", right: "diag-5", up: "diag-2", down: "diag-6" },
      "diag-6": { left: "diag-6", right: "diag-6", up: "diag-3", down: "diag-6" }
    };

    diagnosisTiles.forEach((tile, index) => {
      const key = `diag-${index}`;
      this.registeredKeys.push(key);

      this.focusManager.register({
        key,
        element: this.host.querySelector(`#diag-${index}`),
        neighbors: neighborMap[key],
        onEnter: () => {
          showToast(this.host, `${tile.title} is ready to run.`);
        }
      });
    });
  }
}
