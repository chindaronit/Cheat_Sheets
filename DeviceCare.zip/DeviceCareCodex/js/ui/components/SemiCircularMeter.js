function describeSemiArc(cx, cy, radius) {
  const startX = cx - radius;
  const startY = cy;
  const endX = cx + radius;
  const endY = cy;
  return `M ${startX} ${startY} A ${radius} ${radius} 0 0 1 ${endX} ${endY}`;
}

export function createSemiCircularMeter({ score, label }) {
  const normalizedScore = Math.max(0, Math.min(100, Number(score) || 0));
  const radius = 128;
  const arcPath = describeSemiArc(160, 160, radius);
  const circumference = Math.PI * radius;
  const filled = (normalizedScore / 100) * circumference;
  const gradientId = `meterGradient-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  const root = document.createElement("div");
  root.className = "meter-wrap";
  root.innerHTML = `
    <svg width="320" height="210" viewBox="0 0 320 210" aria-hidden="true">
      <path d="${arcPath}" stroke="rgba(192, 219, 255, 0.28)" stroke-width="9" fill="none" stroke-linecap="round"></path>
      <path d="${arcPath}" stroke="url(#${gradientId})" stroke-width="9" fill="none" stroke-linecap="round" stroke-dasharray="${filled} ${circumference}"></path>
      <defs>
        <linearGradient id="${gradientId}" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#00b9ff" />
          <stop offset="100%" stop-color="#98ffd7" />
        </linearGradient>
      </defs>
    </svg>
    <div class="meter-label">
      <span class="meter-score-icon">&#128737;</span>
      <div class="meter-score-text">${label}</div>
    </div>
  `;

  return root;
}
