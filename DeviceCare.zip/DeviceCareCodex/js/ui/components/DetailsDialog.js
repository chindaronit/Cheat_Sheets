import { formatStorage } from "../../utils/formatters.js";

export class DetailsDialog {
  constructor({ focusManager, host }) {
    this.focusManager = focusManager;
    this.host = host;
    this.overlay = null;
    this.returnFocusKey = null;
    this.handlers = null;
    this.focusKeys = ["dialog-clear-data", "dialog-clear-cache", "dialog-close"];
  }

  isOpen() {
    return Boolean(this.overlay);
  }

  open({ appId, getDetails, onClearData, onClearCache, onClose, returnFocusKey }) {
    this.close(false);

    this.returnFocusKey = returnFocusKey;
    this.handlers = {
      appId,
      getDetails,
      onClearData,
      onClearCache,
      onClose
    };

    this.overlay = document.createElement("div");
    this.overlay.className = "dialog-overlay";
    this.overlay.innerHTML = `
      <section class="details-dialog" role="dialog" aria-modal="true" aria-label="View Details">
        <div class="details-main">
          <h2 class="details-title">View Details</h2>
          <div class="details-app-header">
            <div id="details-app-logo" class="details-app-logo"></div>
            <div id="details-app-name" class="details-app-name"></div>
          </div>
          <div class="details-metrics">
            <div>App</div><div id="details-size-app" class="details-value"></div>
            <div>Data</div><div id="details-size-data" class="details-value"></div>
            <div>Cache</div><div id="details-size-cache" class="details-value"></div>
            <div>Total</div><div id="details-size-total" class="details-value"></div>
          </div>
        </div>
        <div class="details-actions">
          <button id="dialog-clear-data" class="details-action-btn focusable" type="button">Clear Data</button>
          <button id="dialog-clear-cache" class="details-action-btn focusable" type="button">Clear Cache</button>
          <button id="dialog-close" class="details-action-btn focusable" type="button">Close</button>
        </div>
      </section>
    `;

    this.host.appendChild(this.overlay);
    this._bindFocus();
    this.refresh();
    this.focusManager.requestFocus("dialog-close");
  }

  refresh() {
    if (!this.overlay || !this.handlers) {
      return;
    }

    const details = this.handlers.getDetails(this.handlers.appId);
    if (!details) {
      this.close();
      return;
    }

    this.overlay.querySelector("#details-app-logo").textContent = details.logo;
    this.overlay.querySelector("#details-app-name").textContent = details.name;
    this.overlay.querySelector("#details-size-app").textContent = formatStorage(details.sizeAppMb);
    this.overlay.querySelector("#details-size-data").textContent = formatStorage(details.sizeDataMb);
    this.overlay.querySelector("#details-size-cache").textContent = formatStorage(details.sizeCacheMb);
    this.overlay.querySelector("#details-size-total").textContent = formatStorage(details.totalMb);
  }

  close(restoreFocus = true) {
    if (!this.overlay) {
      return;
    }

    for (const key of this.focusKeys) {
      this.focusManager.unregister(key);
    }

    this.overlay.remove();
    this.overlay = null;

    const onClose = this.handlers ? this.handlers.onClose : null;
    this.handlers = null;

    if (onClose) {
      onClose();
    }

    if (restoreFocus && this.returnFocusKey) {
      this.focusManager.requestFocus(this.returnFocusKey);
    }
  }

  async clearData() {
    if (!this.handlers || !this.handlers.onClearData) {
      return;
    }

    await this.handlers.onClearData(this.handlers.appId);
    this.refresh();
  }

  async clearCache() {
    if (!this.handlers || !this.handlers.onClearCache) {
      return;
    }

    await this.handlers.onClearCache(this.handlers.appId);
    this.refresh();
  }

  _bindFocus() {
    const clearDataButton = this.overlay.querySelector("#dialog-clear-data");
    const clearCacheButton = this.overlay.querySelector("#dialog-clear-cache");
    const closeButton = this.overlay.querySelector("#dialog-close");

    this.focusManager.register({
      key: "dialog-clear-data",
      element: clearDataButton,
      neighbors: {
        up: "dialog-close",
        down: "dialog-clear-cache",
        left: "dialog-clear-data",
        right: "dialog-clear-data"
      },
      onEnter: () => {
        this.clearData();
      }
    });

    this.focusManager.register({
      key: "dialog-clear-cache",
      element: clearCacheButton,
      neighbors: {
        up: "dialog-clear-data",
        down: "dialog-close",
        left: "dialog-clear-cache",
        right: "dialog-clear-cache"
      },
      onEnter: () => {
        this.clearCache();
      }
    });

    this.focusManager.register({
      key: "dialog-close",
      element: closeButton,
      neighbors: {
        up: "dialog-clear-cache",
        down: "dialog-clear-data",
        left: "dialog-close",
        right: "dialog-close"
      },
      onEnter: () => {
        this.close();
      }
    });
  }
}
