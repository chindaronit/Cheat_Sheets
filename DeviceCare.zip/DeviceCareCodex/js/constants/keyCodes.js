export const KeyCodes = Object.freeze({
  LEFT: 37,
  UP: 38,
  RIGHT: 39,
  DOWN: 40,
  ENTER: 13,
  SPACE: 32,
  BACKSPACE: 8,
  ESCAPE: 27,
  TIZEN_BACK: 10009
});

export const DirectionByKeyCode = Object.freeze({
  [KeyCodes.LEFT]: "left",
  [KeyCodes.UP]: "up",
  [KeyCodes.RIGHT]: "right",
  [KeyCodes.DOWN]: "down"
});
