export const Routes = Object.freeze({
  HOME: "home",
  MANAGE_STORAGE: "manage-storage",
  SELF_DIAGNOSIS: "self-diagnosis"
});

export const NavigationGraph = Object.freeze({
  [Routes.HOME]: [Routes.MANAGE_STORAGE, Routes.SELF_DIAGNOSIS],
  [Routes.MANAGE_STORAGE]: [Routes.HOME],
  [Routes.SELF_DIAGNOSIS]: [Routes.HOME]
});