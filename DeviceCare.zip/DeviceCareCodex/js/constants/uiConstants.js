export const UIConstants = Object.freeze({
  APP_CARD_WIDTH: 260,
  APP_CARD_GAP: 24,
  APP_ROW_WINDOW_SIZE: 6
});