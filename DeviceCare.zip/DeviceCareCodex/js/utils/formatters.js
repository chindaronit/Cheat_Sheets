export function formatStorage(mbValue) {
  const mb = Number(mbValue);

  if (!Number.isFinite(mb) || mb < 0) {
    return "0 B";
  }

  if (mb >= 1024) {
    return `${(mb / 1024).toFixed(2)} GB`;
  }

  if (mb >= 1) {
    return `${mb.toFixed(2)} MB`;
  }

  return `${(mb * 1024).toFixed(2)} KB`;
}

export function formatPercent(value) {
  const normalized = Number.isFinite(value) ? value : 0;
  return `${Math.max(0, Math.min(100, normalized)).toFixed(0)}%`;
}