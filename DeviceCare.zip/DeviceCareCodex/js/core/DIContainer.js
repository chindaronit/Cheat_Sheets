export class DIContainer {
  constructor() {
    this.singletons = new Map();
    this.factories = new Map();
    this.instances = new Map();
  }

  registerSingleton(token, factory) {
    this.singletons.set(token, factory);
  }

  registerFactory(token, factory) {
    this.factories.set(token, factory);
  }

  resolve(token) {
    if (this.instances.has(token)) {
      return this.instances.get(token);
    }

    if (this.singletons.has(token)) {
      const instance = this.singletons.get(token)(this);
      this.instances.set(token, instance);
      return instance;
    }

    if (this.factories.has(token)) {
      return this.factories.get(token)(this);
    }

    throw new Error(`Dependency not registered: ${token}`);
  }
}