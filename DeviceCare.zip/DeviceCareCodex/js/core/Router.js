export class Router {
  constructor({ initialRoute, graph }) {
    this.currentRoute = initialRoute;
    this.graph = graph;
    this.history = [];
    this.listeners = new Set();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  start() {
    this._notify({
      type: "start",
      from: null,
      to: this.currentRoute,
      params: {}
    });
  }

  getCurrentRoute() {
    return this.currentRoute;
  }

  getHistoryDepth() {
    return this.history.length;
  }

  canNavigate(targetRoute) {
    if (!this.currentRoute) {
      return true;
    }

    const allowedRoutes = this.graph[this.currentRoute] || [];
    return allowedRoutes.includes(targetRoute);
  }

  navigate(targetRoute, params = {}) {
    if (targetRoute === this.currentRoute) {
      return false;
    }

    if (!this.canNavigate(targetRoute)) {
      return false;
    }

    const from = this.currentRoute;
    this.history.push(from);
    this.currentRoute = targetRoute;

    this._notify({
      type: "navigate",
      from,
      to: targetRoute,
      params
    });

    return true;
  }

  back(params = {}) {
    if (!this.history.length) {
      return false;
    }

    const from = this.currentRoute;
    const targetRoute = this.history.pop();
    this.currentRoute = targetRoute;

    this._notify({
      type: "back",
      from,
      to: targetRoute,
      params
    });

    return true;
  }

  _notify(change) {
    for (const listener of this.listeners) {
      listener(change);
    }
  }
}
