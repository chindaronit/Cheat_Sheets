export class VirtualRow {
  constructor({ trackElement, itemWidth, gap, windowSize, renderItem }) {
    this.trackElement = trackElement;
    this.itemWidth = itemWidth;
    this.gap = gap;
    this.windowSize = windowSize;
    this.renderItem = renderItem;
    this.items = [];
    this.cursorIndex = 0;
    this.visibleRange = { start: 0, end: 0 };
  }

  setItems(items) {
    this.items = [...items];
  }

  setCursorIndex(index) {
    const lastIndex = Math.max(0, this.items.length - 1);
    this.cursorIndex = Math.max(0, Math.min(index, lastIndex));
  }

  render() {
    this.trackElement.innerHTML = "";

    if (!this.items.length) {
      this.visibleRange = { start: 0, end: 0 };
      return this.visibleRange;
    }

    let start = Math.max(0, this.cursorIndex - Math.floor(this.windowSize / 2));
    let end = Math.min(this.items.length, start + this.windowSize);
    start = Math.max(0, end - this.windowSize);

    const leftSpacerWidth = start * (this.itemWidth + this.gap);
    const rightSpacerWidth = Math.max(0, this.items.length - end) * (this.itemWidth + this.gap);

    const fragment = document.createDocumentFragment();

    if (leftSpacerWidth > 0) {
      const leftSpacer = document.createElement("div");
      leftSpacer.className = "virtual-spacer";
      leftSpacer.style.width = `${leftSpacerWidth}px`;
      fragment.appendChild(leftSpacer);
    }

    for (let index = start; index < end; index += 1) {
      const item = this.items[index];
      const rendered = this.renderItem(item, index, index === this.cursorIndex);
      fragment.appendChild(rendered);
    }

    if (rightSpacerWidth > 0) {
      const rightSpacer = document.createElement("div");
      rightSpacer.className = "virtual-spacer";
      rightSpacer.style.width = `${rightSpacerWidth}px`;
      fragment.appendChild(rightSpacer);
    }

    this.trackElement.appendChild(fragment);
    this.visibleRange = { start, end };
    return this.visibleRange;
  }
}