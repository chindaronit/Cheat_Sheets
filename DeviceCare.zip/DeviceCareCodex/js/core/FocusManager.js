function isElementVisible(element) {
  if (!element || !element.isConnected) {
    return false;
  }

  const style = window.getComputedStyle(element);
  if (style.display === "none" || style.visibility === "hidden") {
    return false;
  }

  return true;
}

function getCenter(rect) {
  return {
    x: rect.left + rect.width / 2,
    y: rect.top + rect.height / 2
  };
}

export class FocusManager {
  constructor() {
    this.registry = new Map();
    this.activeKey = null;
  }

  register({ key, element, neighbors = {}, onEnter = null }) {
    if (!key || !element) {
      return;
    }

    element.setAttribute("tabindex", "-1");
    element.dataset.focusKey = key;
    this.registry.set(key, { key, element, neighbors, onEnter });

    element.addEventListener("focus", () => {
      this.setActiveKey(key);
    });

    element.addEventListener("click", () => {
      // Allow mouse / emulator click to behave like remote "Enter".
      this.setActiveKey(key);
      if (onEnter) {
        onEnter();
      }
    });
  }

  unregister(key) {
    const target = this.registry.get(key);
    if (!target) {
      return;
    }

    target.element.classList.remove("is-focused");
    this.registry.delete(key);

    if (this.activeKey === key) {
      this.activeKey = null;
    }
  }

  updateNeighbors(key, neighbors) {
    const target = this.registry.get(key);
    if (!target) {
      return;
    }

    target.neighbors = neighbors;
  }

  clear() {
    for (const node of this.registry.values()) {
      node.element.classList.remove("is-focused");
    }

    this.registry.clear();
    this.activeKey = null;
  }

  getActiveKey() {
    return this.activeKey;
  }

  setActiveKey(key) {
    if (this.activeKey && this.registry.has(this.activeKey)) {
      this.registry.get(this.activeKey).element.classList.remove("is-focused");
    }

    this.activeKey = key;

    if (this.registry.has(key)) {
      this.registry.get(key).element.classList.add("is-focused");
    }
  }

  requestFocus(key) {
    const target = this.registry.get(key);

    if (!target || !isElementVisible(target.element)) {
      return false;
    }

    this.setActiveKey(key);
    target.element.focus({ preventScroll: true });
    return true;
  }

  activate() {
    if (!this.activeKey || !this.registry.has(this.activeKey)) {
      return false;
    }

    const target = this.registry.get(this.activeKey);
    if (target.onEnter) {
      target.onEnter();
      return true;
    }

    target.element.click();
    return true;
  }

  move(direction) {
    if (!this.activeKey || !this.registry.has(this.activeKey)) {
      const [first] = this.registry.keys();
      return first ? this.requestFocus(first) : false;
    }

    const activeNode = this.registry.get(this.activeKey);
    const explicitTargetKey = activeNode.neighbors[direction];

    if (explicitTargetKey && this.requestFocus(explicitTargetKey)) {
      return true;
    }

    const spatialTargetKey = this._findSpatialTarget(this.activeKey, direction);
    if (spatialTargetKey) {
      return this.requestFocus(spatialTargetKey);
    }

    return false;
  }

  _findSpatialTarget(fromKey, direction) {
    const fromNode = this.registry.get(fromKey);
    if (!fromNode || !isElementVisible(fromNode.element)) {
      return null;
    }

    const fromRect = fromNode.element.getBoundingClientRect();
    const fromCenter = getCenter(fromRect);
    let bestKey = null;
    let bestDistance = Number.POSITIVE_INFINITY;

    for (const [candidateKey, candidate] of this.registry.entries()) {
      if (candidateKey === fromKey || !isElementVisible(candidate.element)) {
        continue;
      }

      const rect = candidate.element.getBoundingClientRect();
      const center = getCenter(rect);
      const deltaX = center.x - fromCenter.x;
      const deltaY = center.y - fromCenter.y;

      if (direction === "left" && deltaX >= 0) {
        continue;
      }
      if (direction === "right" && deltaX <= 0) {
        continue;
      }
      if (direction === "up" && deltaY >= 0) {
        continue;
      }
      if (direction === "down" && deltaY <= 0) {
        continue;
      }

      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
      if (distance < bestDistance) {
        bestDistance = distance;
        bestKey = candidateKey;
      }
    }

    return bestKey;
  }
}
