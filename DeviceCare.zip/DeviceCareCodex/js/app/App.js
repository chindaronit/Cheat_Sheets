import { DIContainer } from "../core/DIContainer.js";
import { Router } from "../core/Router.js";
import { FocusManager } from "../core/FocusManager.js";
import { Routes, NavigationGraph } from "../constants/routes.js";
import { DirectionByKeyCode, KeyCodes } from "../constants/keyCodes.js";
import { TizenStorageService } from "../data/services/TizenStorageService.js";
import { DeviceCareRepository } from "../data/repositories/DeviceCareRepository.js";
import { HomeScreen } from "../ui/screens/HomeScreen.js";
import { ManageStorageScreen } from "../ui/screens/ManageStorageScreen.js";
import { SelfDiagnosisScreen } from "../ui/screens/SelfDiagnosisScreen.js";

export class App {
  constructor(rootElement) {
    this.rootElement = rootElement;
    this.container = new DIContainer();

    this.router = null;
    this.focusManager = null;
    this.repository = null;

    this.screens = {};
    this.currentRoute = null;
    this.currentScreen = null;
    this.focusMemory = new Map();

    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.handleTizenKey = this.handleTizenKey.bind(this);
  }

  start() {
    this._configureDependencies();
    this._createScreens();
    this._bindGlobalInput();

    Promise.resolve(this.repository.initialize())
      .catch(() => {
        // Repository fallback data will still allow app boot.
      })
      .then(() => {
        this.router.start();
      });
  }

  _configureDependencies() {
    this.container.registerSingleton("focusManager", () => new FocusManager());
    this.container.registerSingleton("storageService", () => new TizenStorageService());
    this.container.registerSingleton("repository", (container) => new DeviceCareRepository({
      storageService: container.resolve("storageService")
    }));
    this.container.registerSingleton("router", () => new Router({
      initialRoute: Routes.HOME,
      graph: NavigationGraph
    }));

    this.focusManager = this.container.resolve("focusManager");
    this.repository = this.container.resolve("repository");
    this.router = this.container.resolve("router");

    this.router.subscribe((change) => {
      this._onRouteChanged(change);
    });
  }

  _createScreens() {
    this.screens = {
      [Routes.HOME]: new HomeScreen({
        router: this.router,
        repository: this.repository,
        focusManager: this.focusManager
      }),
      [Routes.MANAGE_STORAGE]: new ManageStorageScreen({
        repository: this.repository,
        focusManager: this.focusManager
      }),
      [Routes.SELF_DIAGNOSIS]: new SelfDiagnosisScreen({
        focusManager: this.focusManager
      })
    };
  }

  _bindGlobalInput() {
    if (window.tizen && window.tizen.tvinputdevice && window.tizen.tvinputdevice.registerKey) {
      try {
        window.tizen.tvinputdevice.registerKey("ColorF0Red");
        window.tizen.tvinputdevice.registerKey("ColorF1Green");
      } catch (_error) {
        // Key registration is optional for this app.
      }
    }

    document.addEventListener("keydown", this.handleKeyDown);
    window.addEventListener("tizenhwkey", this.handleTizenKey);
  }

  handleKeyDown(event) {
    const keyCode = event.keyCode;

    if (
      DirectionByKeyCode[keyCode] ||
      keyCode === KeyCodes.ENTER ||
      keyCode === KeyCodes.SPACE ||
      keyCode === KeyCodes.BACKSPACE ||
      keyCode === KeyCodes.ESCAPE ||
      keyCode === KeyCodes.TIZEN_BACK
    ) {
      event.preventDefault();
    }

    if (this.currentScreen && this.currentScreen.onKeyDown(event)) {
      return;
    }

    const direction = DirectionByKeyCode[keyCode];
    if (direction) {
      this.focusManager.move(direction);
      return;
    }

    if (keyCode === KeyCodes.ENTER || keyCode === KeyCodes.SPACE) {
      this.focusManager.activate();
      return;
    }

    if (keyCode === KeyCodes.BACKSPACE || keyCode === KeyCodes.ESCAPE || keyCode === KeyCodes.TIZEN_BACK) {
      this._handleBackAction();
    }
  }

  handleTizenKey(event) {
    if (event.keyName === "back") {
      this._handleBackAction();
    }
  }

  _handleBackAction() {
    if (this.currentScreen && this.currentScreen.handleBack()) {
      return;
    }

    const didGoBack = this.router.back();
    if (didGoBack) {
      return;
    }

    if (window.tizen && window.tizen.application && window.tizen.application.getCurrentApplication) {
      window.tizen.application.getCurrentApplication().exit();
    }
  }

  _onRouteChanged(change) {
    if (this.currentRoute && this.currentScreen) {
      this.focusMemory.set(this.currentRoute, this.currentScreen.getFocusedKey());
      this.currentScreen.unmount();
    }

    this.currentRoute = change.to;
    this.currentScreen = this.screens[change.to];

    const restoreFocusKey = this.focusMemory.get(change.to);
    this.currentScreen.mount(this.rootElement, {
      restoreFocusKey
    });
  }
}
