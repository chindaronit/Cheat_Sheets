function cloneApp(app) {
  return {
    ...app,
    selected: Boolean(app.selected),
    totalMb: Number((app.sizeAppMb + app.sizeDataMb + app.sizeCacheMb).toFixed(4))
  };
}

function toInitials(label) {
  const words = String(label || "")
    .split(/\s+/)
    .filter(Boolean);

  if (!words.length) {
    return "AP";
  }

  if (words.length === 1) {
    return words[0].slice(0, 2).toUpperCase();
  }

  return `${words[0][0]}${words[1][0]}`.toUpperCase();
}

function hashCode(value) {
  let hash = 0;
  const text = String(value || "");
  for (let i = 0; i < text.length; i += 1) {
    hash = ((hash << 5) - hash) + text.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

function pickGradient(source) {
  const palette = [
    ["#8a2d17", "#d9552b"],
    ["#2e39ff", "#0328aa"],
    ["#9d09e7", "#4f0caf"],
    ["#0b7892", "#1da8b0"],
    ["#7d4b1d", "#b67a2e"],
    ["#205774", "#4ba7c7"],
    ["#63289d", "#8f4ad9"],
    ["#3a4d18", "#6a9232"]
  ];

  return palette[hashCode(source) % palette.length];
}

function estimateSizes(seedText) {
  const hash = hashCode(seedText);
  const appMb = 0.4 + ((hash % 2000) / 100);
  const dataMb = 0.05 + (((hash >> 2) % 900) / 200);
  const cacheMb = ((hash >> 5) % 70) / 100;

  return {
    sizeAppMb: Number(appMb.toFixed(3)),
    sizeDataMb: Number(dataMb.toFixed(3)),
    sizeCacheMb: Number(cacheMb.toFixed(3))
  };
}

function normalizeTizenApp(appInfo) {
  const source = appInfo || {};
  const id = source.id || source.appId || source.packageId || "";
  const name = source.name || source.label || id || "Unknown App";
  const [gradientA, gradientB] = pickGradient(id || name);
  const estimated = estimateSizes(`${id}|${name}`);

  return {
    id: id || name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    name,
    logo: toInitials(name),
    gradientA,
    gradientB,
    ...estimated,
    selected: false
  };
}

export class DeviceCareRepository {
  constructor({ storageService }) {
    this.storageService = storageService;
    this.listeners = new Set();

    this.health = {
      score: 84,
      label: "Good"
    };

    this.totalStorageMb = 17408;
    this.baseSystemUsageMb = 1840;
    this.apps = [
      {
        id: "xstream-play",
        name: "Xstream Play",
        logo: "XP",
        gradientA: "#8a2d17",
        gradientB: "#d9552b",
        sizeAppMb: 0.715,
        sizeDataMb: 0.678,
        sizeCacheMb: 0,
        selected: false
      },
      {
        id: "stay-home-fitness",
        name: "Stay Home Fitness",
        logo: "SH",
        gradientA: "#d7dbe7",
        gradientB: "#f4f6ff",
        sizeAppMb: 9.02,
        sizeDataMb: 9.91,
        sizeCacheMb: 0.91,
        selected: false
      },
      {
        id: "clock-o-clock-music",
        name: "clock o clock + music",
        logo: "CO",
        gradientA: "#d9dde7",
        gradientB: "#f8f8fc",
        sizeAppMb: 0.412,
        sizeDataMb: 0.349,
        sizeCacheMb: 0.01,
        selected: false
      },
      {
        id: "yogifi",
        name: "YogiFi",
        logo: "YF",
        gradientA: "#856736",
        gradientB: "#5c4d27",
        sizeAppMb: 2.1,
        sizeDataMb: 1.05,
        sizeCacheMb: 0.06,
        selected: false
      },
      {
        id: "jiocinema",
        name: "JioCinema",
        logo: "JC",
        gradientA: "#9d09e7",
        gradientB: "#4f0caf",
        sizeAppMb: 0.72,
        sizeDataMb: 0.28,
        sizeCacheMb: 0.004,
        selected: false
      },
      {
        id: "samsung-experience-plus",
        name: "Samsung Experience Plus",
        logo: "SE",
        gradientA: "#2e39ff",
        gradientB: "#0328aa",
        sizeAppMb: 2.3,
        sizeDataMb: 1.31,
        sizeCacheMb: 0.11,
        selected: false
      }
    ];
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  async initialize() {
    const installedApps = await this.storageService.getInstalledApplications();
    if (!Array.isArray(installedApps) || !installedApps.length) {
      return;
    }

    const normalizedApps = installedApps
      .map((item) => normalizeTizenApp(item))
      .filter((app, index, list) => app.id && list.findIndex((v) => v.id === app.id) === index)
      .slice(0, 60);

    if (!normalizedApps.length) {
      return;
    }

    this.apps = normalizedApps;
    this._emit();
  }

  _emit() {
    const snapshot = this.getStateSnapshot();
    for (const listener of this.listeners) {
      listener(snapshot);
    }
  }

  getStateSnapshot() {
    return {
      health: this.getHealth(),
      storage: this.getStorageSummary(),
      apps: this.getInstalledApps(),
      selectedCount: this.getSelectedCount()
    };
  }

  getHealth() {
    return { ...this.health };
  }

  getInstalledApps() {
    return this.apps.map((app) => cloneApp(app));
  }

  getSelectedCount() {
    return this.apps.filter((app) => app.selected).length;
  }

  getStorageSummary() {
    const appUsageMb = this.apps.reduce((sum, app) => sum + app.sizeAppMb + app.sizeDataMb + app.sizeCacheMb, 0);
    const usedMb = this.baseSystemUsageMb + appUsageMb;
    const availableMb = Math.max(0, this.totalStorageMb - usedMb);
    const usedPercent = Math.min(100, (usedMb / this.totalStorageMb) * 100);

    return {
      usedMb,
      totalMb: this.totalStorageMb,
      availableMb,
      usedPercent
    };
  }

  toggleSelection(appId) {
    const app = this.apps.find((item) => item.id === appId);
    if (!app) {
      return;
    }

    app.selected = !app.selected;
    this._emit();
  }

  clearSelection() {
    let changed = false;

    for (const app of this.apps) {
      if (app.selected) {
        app.selected = false;
        changed = true;
      }
    }

    if (changed) {
      this._emit();
    }
  }

  async deleteSelectedApplications() {
    const selected = this.apps.filter((app) => app.selected);
    if (!selected.length) {
      return 0;
    }

    for (const app of selected) {
      await this.storageService.uninstallApplication(app.id);
    }

    this.apps = this.apps.filter((app) => !app.selected);
    this._emit();
    return selected.length;
  }

  getAppDetails(appId) {
    const app = this.apps.find((item) => item.id === appId);
    if (!app) {
      return null;
    }

    return cloneApp(app);
  }

  async clearAppData(appId) {
    const app = this.apps.find((item) => item.id === appId);
    if (!app) {
      return false;
    }

    await this.storageService.clearData(appId);
    app.sizeDataMb = 0;
    this._emit();
    return true;
  }

  async clearAppCache(appId) {
    const app = this.apps.find((item) => item.id === appId);
    if (!app) {
      return false;
    }

    await this.storageService.clearCache(appId);
    app.sizeCacheMb = 0;
    this._emit();
    return true;
  }
}
