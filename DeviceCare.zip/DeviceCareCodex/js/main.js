import { App } from "./app/App.js";

window.addEventListener("DOMContentLoaded", () => {
  const root = document.getElementById("app");
  const app = new App(root);
  app.start();
});