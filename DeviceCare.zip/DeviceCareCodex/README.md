# Device Care - Tizen TV Web Application

Device Care is a production-oriented Tizen TV web application implementing the requested flows:
- Home
- Manage Storage
- View Details dialog
- Self-Diagnosis

The app is built with a modular architecture (DI container, repository layer, router, focus manager, lazy virtual row) and optimized for TV UX (DPAD-only, focus restoration, overscan-safe layout, 10-foot sizing).

## 1. Project Structure

```text
DeviceCare/
  assets/
    icons/icon.png
  css/
    styles.css
  docs/
    ARCHITECTURE.md
    EMULATOR_SETUP.md
    NAVIGATION_GRAPH.md
    REQUIREMENTS.md
    SEQUENCE_DIAGRAMS.md
  js/
    app/App.js
    constants/
      keyCodes.js
      routes.js
      uiConstants.js
    core/
      DIContainer.js
      FocusManager.js
      Router.js
      VirtualRow.js
    data/
      repositories/DeviceCareRepository.js
      services/TizenStorageService.js
    ui/
      components/
        DetailsDialog.js
        SemiCircularMeter.js
      screens/
        HomeScreen.js
        ManageStorageScreen.js
        SelfDiagnosisScreen.js
    utils/
      dom.js
      formatters.js
    main.js
  scripts/
    build.ps1
  .project
  .tproject
  config.xml
  index.html
```

## 2. Core Features Implemented

- Home screen with semi-circular health meter and three action cards.
- Manage Storage screen with:
  - Used/available storage progress summary.
  - Selected count + Deselect/Delete actions.
  - Horizontally virtualized app cards (LazyRow-style behavior).
  - Focus-driven View Details button bound to active card.
- View Details dialog with Clear Data, Clear Cache, and Close actions.
- Self-Diagnosis screen with focus-scale cards in a TV grid.
- DPAD navigation and Enter handling.
- Back handling:
  - Close dialog first.
  - Navigate to previous route.
  - Exit app when no back stack remains.
- Focus restoration on route return.

## 3. Tizen Studio Build and Run

### GUI flow (recommended)
1. Open Tizen Studio.
2. Import this folder as an existing project.
3. Open `config.xml` and verify profile is TV (`tv`).
4. Create or select a certificate profile.
5. Build project (`Build Project`).
6. Package and run on TV emulator/device.

### CLI flow (if CLI is available)
From project root:

```powershell
$env:PATH = "C:\tizen-studio\tools\ide\bin;$env:PATH"
tizen build-web -- .
tizen package --type wgt --sign "<security-profile>" -- .output
```

Generated package is under `.output\`.

## 4. Emulator Setup (Manual, TV Extension)

In Tizen Studio Package Manager:
1. Add extension repository: `https://download.tizen.org/sdk/extensions/tv_extensions/`
2. Install TV extension package group for your target version.
3. Install emulator packages from the same TV extension group.
4. Launch Emulator Manager and create a TV virtual device.

Detailed guide: `docs/EMULATOR_SETUP.md`

## 5. Input Model

- No touch interactions.
- Remote keys:
  - Arrow keys: focus move.
  - Enter: activate focused component.
  - Back/Escape/Backspace: dialog close or route back.

## 6. Notes on Repository + Device APIs

`DeviceCareRepository` uses curated fallback app data and automatically swaps to installed-app data when Tizen APIs are available.
`TizenStorageService` is isolated so native Tizen app/storage operations can be expanded without touching UI layers.

## 7. Documentation

- Architecture and class design: `docs/ARCHITECTURE.md`
- Navigation graph: `docs/NAVIGATION_GRAPH.md`
- Sequence diagrams: `docs/SEQUENCE_DIAGRAMS.md`
- Functional/non-functional requirements: `docs/REQUIREMENTS.md`
